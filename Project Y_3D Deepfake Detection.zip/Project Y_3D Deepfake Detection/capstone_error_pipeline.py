import argparse
import csv
import hashlib
import os
import random
import re
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
from tqdm import tqdm


DEFAULT_OUTPUT_ROOT = "/mnt/SSD/yerin/capstone"
DEFAULT_NEXTFACE_DIR = "/home/yerin/NextFace-map1024"
DEFAULT_SELECT_BEST_DIR = "/home/yerin/방송미디어공학회"


def add_import_paths(select_best_dir):
    select_best_dir = str(Path(select_best_dir))
    if select_best_dir not in sys.path:
        sys.path.insert(0, select_best_dir)


def list_videos(root):
    root = Path(root)
    if not root.exists():
        return []
    return sorted(p for p in root.rglob("*.mp4") if p.is_file())


def make_pair_id(dataset, method, fake_video):
    stem = Path(fake_video).stem
    digest = hashlib.sha1(str(fake_video).encode("utf-8")).hexdigest()[:8]
    safe_method = re.sub(r"[^A-Za-z0-9_-]+", "-", method)
    return f"{dataset}_{safe_method}_{stem}_{digest}"


def read_frame(video_path, frame_idx):
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return None
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(frame_idx))
    ok, frame = cap.read()
    cap.release()
    if not ok:
        return None
    return frame


def largest_face(app, frame):
    faces = app.get(frame)
    if len(faces) == 0:
        return None
    return max(
        faces,
        key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]),
    )


def sampled_frame_indices(cap, sample_interval, max_frame_samples):
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total_frames <= 0:
        return None

    if max_frame_samples and max_frame_samples > 0:
        indices = np.linspace(0, max(total_frames - 1, 0), num=min(max_frame_samples, total_frames))
        indices = np.unique(np.rint(indices).astype(np.int64))
        if sample_interval > 1:
            indices = (indices // sample_interval) * sample_interval
            indices = np.unique(np.clip(indices, 0, total_frames - 1))
        return indices.tolist()

    return list(range(0, total_frames, max(sample_interval, 1)))


def select_frame_candidates(video_path, app, top_m, sample_interval, min_gap, max_frame_samples):
    from select_best_frames import best_view_score

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return []

    candidates = []
    frame_indices = sampled_frame_indices(cap, sample_interval, max_frame_samples)

    if frame_indices is None:
        frame_indices = []
        frame_idx = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if frame_idx % sample_interval == 0:
                frame_indices.append(frame_idx)
            frame_idx += 1

    for frame_idx in frame_indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(frame_idx))
        ok, frame = cap.read()
        if not ok:
            continue
        face = largest_face(app, frame)
        if face is None:
            continue

        score = best_view_score(frame, face)
        candidates.append(
            {
                "frame_idx": frame_idx,
                "score": float(score),
                "frame": frame.copy(),
                "face": face,
            }
        )

    cap.release()
    candidates.sort(key=lambda item: item["score"], reverse=True)

    selected = []
    for cand in candidates:
        if all(abs(cand["frame_idx"] - item["frame_idx"]) >= min_gap for item in selected):
            selected.append(cand)
        if len(selected) >= top_m:
            break

    return selected


def frame_difference(a, b):
    if a.shape[:2] != b.shape[:2]:
        b = cv2.resize(b, (a.shape[1], a.shape[0]), interpolation=cv2.INTER_LINEAR)
    a_small = cv2.resize(a, (64, 64), interpolation=cv2.INTER_AREA).astype(np.float32)
    b_small = cv2.resize(b, (64, 64), interpolation=cv2.INTER_AREA).astype(np.float32)
    return float(np.mean(np.abs(a_small - b_small)) / 255.0)


def bbox_penalty(fake_face, real_face, frame_shape):
    h, w = frame_shape[:2]
    fb = fake_face.bbox.astype(np.float32)
    rb = real_face.bbox.astype(np.float32)

    fc = np.array([(fb[0] + fb[2]) / 2.0 / w, (fb[1] + fb[3]) / 2.0 / h])
    rc = np.array([(rb[0] + rb[2]) / 2.0 / w, (rb[1] + rb[3]) / 2.0 / h])
    fs = np.array([(fb[2] - fb[0]) / w, (fb[3] - fb[1]) / h])
    rs = np.array([(rb[2] - rb[0]) / w, (rb[3] - rb[1]) / h])
    return float(np.linalg.norm(fc - rc) + 0.5 * np.linalg.norm(fs - rs))


def choose_matched_real(fake_candidates, real_videos, app, used_real_counts, max_fakes_per_real):
    best = None

    for cand in fake_candidates:
        fake_frame = cand["frame"]
        fake_face = cand["face"]
        frame_idx = cand["frame_idx"]

        for real_video in real_videos:
            real_video = Path(real_video)
            if used_real_counts.get(str(real_video), 0) >= max_fakes_per_real:
                continue

            real_frame = read_frame(real_video, frame_idx)
            if real_frame is None:
                continue

            if real_frame.shape[:2] != fake_frame.shape[:2]:
                real_frame = cv2.resize(
                    real_frame,
                    (fake_frame.shape[1], fake_frame.shape[0]),
                    interpolation=cv2.INTER_LINEAR,
                )

            real_face = largest_face(app, real_frame)
            if real_face is None:
                continue

            diff = frame_difference(fake_frame, real_frame)
            penalty = bbox_penalty(fake_face, real_face, fake_frame.shape)
            match_score = diff + 0.25 * penalty - 0.01 * cand["score"]

            if best is None or match_score < best["match_score"]:
                best = {
                    "frame_idx": frame_idx,
                    "score": cand["score"],
                    "match_score": match_score,
                    "fake_frame": fake_frame,
                    "fake_face": fake_face,
                    "real_video": real_video,
                    "real_frame": real_frame,
                    "real_face": real_face,
                }

        if best is not None:
            return best

    return None


def celeb_real_candidates(fake_video, real_map):
    match = re.match(r"^(id\d+)_(id\d+)_(\d+)$", Path(fake_video).stem)
    if not match:
        return []
    src_id, dst_id, clip_id = match.groups()
    candidates = []
    for real_stem in (f"{dst_id}_{clip_id}", f"{src_id}_{clip_id}"):
        if real_stem in real_map:
            candidates.append(real_map[real_stem])
    return candidates


def ffpp_real_candidates(fake_video, real_map):
    match = re.match(r"^(\d+)_(\d+)$", Path(fake_video).stem)
    if not match:
        return []
    first, second = match.groups()
    candidates = []
    for real_stem in (second, first):
        if real_stem in real_map:
            candidates.append(real_map[real_stem])
    return candidates


def allocate_counts(total, names):
    base = total // len(names)
    rem = total % len(names)
    return {name: base + (1 if idx < rem else 0) for idx, name in enumerate(names)}


def build_video_pairs(args, app):
    rng = random.Random(args.seed)
    used_real_counts = {}
    pairs = []

    total_pairs = args.total_images // 2
    celeb_pairs = args.celeb_pairs
    ffpp_pairs = total_pairs - celeb_pairs

    celeb_real_videos = list_videos(args.celeb_real_root)
    celeb_fake_videos = list_videos(args.celeb_fake_root)
    celeb_real_map = {p.stem: p for p in celeb_real_videos}
    rng.shuffle(celeb_fake_videos)

    with tqdm(total=celeb_pairs, desc="Celeb-DF pair selection") as pbar:
        for fake_video in celeb_fake_videos:
            if len([p for p in pairs if p["dataset"] == "celebdf"]) >= celeb_pairs:
                break

            real_candidates = celeb_real_candidates(fake_video, celeb_real_map)
            if not real_candidates:
                continue

            fake_candidates = select_frame_candidates(
                fake_video,
                app,
                args.top_m,
                args.sample_interval,
                args.min_gap,
                args.max_frame_samples,
            )
            if not fake_candidates:
                continue

            match = choose_matched_real(
                fake_candidates,
                real_candidates,
                app,
                used_real_counts,
                args.max_fakes_per_real,
            )
            if match is None:
                continue

            pair_id = make_pair_id("celebdf", "synthesis", fake_video)
            pairs.append(pair_record(pair_id, "celebdf", "synthesis", fake_video, match))
            used_real_counts[str(match["real_video"])] = used_real_counts.get(str(match["real_video"]), 0) + 1
            pbar.update(1)

    ffpp_real_videos = list_videos(args.ffpp_real_root)
    ffpp_real_map = {}
    for real_video in ffpp_real_videos:
        ffpp_real_map.setdefault(real_video.stem, real_video)

    method_counts = allocate_counts(ffpp_pairs, args.ffpp_methods)
    for method, need_count in method_counts.items():
        method_root = Path(args.ffpp_fake_root) / method / "c23" / "videos"
        fake_videos = list_videos(method_root)
        rng.shuffle(fake_videos)

        with tqdm(total=need_count, desc=f"FF++ {method} pair selection") as pbar:
            selected_for_method = 0
            for fake_video in fake_videos:
                if selected_for_method >= need_count:
                    break

                real_candidates = ffpp_real_candidates(fake_video, ffpp_real_map)
                if not real_candidates:
                    continue

                fake_candidates = select_frame_candidates(
                    fake_video,
                    app,
                    args.top_m,
                    args.sample_interval,
                    args.min_gap,
                    args.max_frame_samples,
                )
                if not fake_candidates:
                    continue

                match = choose_matched_real(
                    fake_candidates,
                    real_candidates,
                    app,
                    used_real_counts,
                    args.max_fakes_per_real,
                )
                if match is None:
                    continue

                pair_id = make_pair_id("ffpp", method, fake_video)
                pairs.append(pair_record(pair_id, "ffpp", method, fake_video, match))
                used_real_counts[str(match["real_video"])] = used_real_counts.get(str(match["real_video"]), 0) + 1
                selected_for_method += 1
                pbar.update(1)

    return pairs


def pair_record(pair_id, dataset, method, fake_video, match):
    return {
        "pair_id": pair_id,
        "dataset": dataset,
        "method": method,
        "fake_video": str(fake_video),
        "real_video": str(match["real_video"]),
        "frame_idx": int(match["frame_idx"]),
        "best_score": f"{match['score']:.6f}",
        "match_score": f"{match['match_score']:.6f}",
        "status": "selected",
        "failed_reason": "",
    }


def write_manifest(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "pair_id",
        "dataset",
        "method",
        "fake_video",
        "real_video",
        "frame_idx",
        "best_score",
        "match_score",
        "real_frame_path",
        "fake_frame_path",
        "real_crop_path",
        "fake_crop_path",
        "real_recon_dir",
        "fake_recon_dir",
        "real_error_dir",
        "fake_error_dir",
        "paired_error_dir",
        "status",
        "failed_reason",
    ]
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def read_manifest(path):
    rows = []
    with Path(path).open("r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(dict(row))
    return rows


def bbox_from_face(face):
    return face.bbox.astype(np.float32)


def paired_square_bbox(real_face, fake_face, margin, width, height):
    rb = bbox_from_face(real_face)
    fb = bbox_from_face(fake_face)
    x1 = min(rb[0], fb[0])
    y1 = min(rb[1], fb[1])
    x2 = max(rb[2], fb[2])
    y2 = max(rb[3], fb[3])

    cx = 0.5 * (x1 + x2)
    cy = 0.5 * (y1 + y2)
    box_size = max(x2 - x1, y2 - y1) * (1.0 + margin)

    left = int(round(cx - box_size / 2.0))
    top = int(round(cy - box_size / 2.0))
    right = int(round(cx + box_size / 2.0))
    bottom = int(round(cy + box_size / 2.0))
    return left, top, right, bottom


def crop_square_with_padding(frame, bbox, output_size):
    left, top, right, bottom = bbox
    h, w = frame.shape[:2]
    pad_left = max(0, -left)
    pad_top = max(0, -top)
    pad_right = max(0, right - w)
    pad_bottom = max(0, bottom - h)

    padded = cv2.copyMakeBorder(
        frame,
        pad_top,
        pad_bottom,
        pad_left,
        pad_right,
        borderType=cv2.BORDER_REPLICATE,
    )
    left += pad_left
    right += pad_left
    top += pad_top
    bottom += pad_top

    crop = padded[top:bottom, left:right]
    if crop.size == 0:
        return None
    return cv2.resize(crop, (output_size, output_size), interpolation=cv2.INTER_LINEAR)


def prepare_frames_and_crops(rows, args, app, manifest_path):
    for row in tqdm(rows, desc="Frames + pair-consistent crops"):
        if row.get("real_crop_path") and row.get("fake_crop_path") and Path(row["real_crop_path"]).exists() and Path(row["fake_crop_path"]).exists():
            continue

        pair_dir = Path(args.output_root) / "frames" / row["dataset"] / row["pair_id"]
        crop_dir = Path(args.output_root) / "crops_256" / row["dataset"] / row["pair_id"]
        pair_dir.mkdir(parents=True, exist_ok=True)
        crop_dir.mkdir(parents=True, exist_ok=True)

        frame_idx = int(row["frame_idx"])
        real_frame = read_frame(row["real_video"], frame_idx)
        fake_frame = read_frame(row["fake_video"], frame_idx)
        if real_frame is None or fake_frame is None:
            mark_failed(row, "frame_read_failed")
            write_manifest(manifest_path, rows)
            continue

        if real_frame.shape[:2] != fake_frame.shape[:2]:
            real_frame = cv2.resize(
                real_frame,
                (fake_frame.shape[1], fake_frame.shape[0]),
                interpolation=cv2.INTER_LINEAR,
            )

        real_face = largest_face(app, real_frame)
        fake_face = largest_face(app, fake_frame)
        if real_face is None or fake_face is None:
            mark_failed(row, "face_detection_failed_for_crop")
            write_manifest(manifest_path, rows)
            continue

        bbox = paired_square_bbox(
            real_face,
            fake_face,
            args.crop_margin,
            fake_frame.shape[1],
            fake_frame.shape[0],
        )

        real_crop = crop_square_with_padding(real_frame, bbox, args.output_size)
        fake_crop = crop_square_with_padding(fake_frame, bbox, args.output_size)
        if real_crop is None or fake_crop is None:
            mark_failed(row, "empty_crop")
            write_manifest(manifest_path, rows)
            continue

        real_frame_path = pair_dir / "real_frame.jpg"
        fake_frame_path = pair_dir / "fake_frame.jpg"
        real_crop_path = crop_dir / "real.png"
        fake_crop_path = crop_dir / "fake.png"

        cv2.imwrite(str(real_frame_path), real_frame)
        cv2.imwrite(str(fake_frame_path), fake_frame)
        cv2.imwrite(str(real_crop_path), real_crop)
        cv2.imwrite(str(fake_crop_path), fake_crop)

        row["real_frame_path"] = str(real_frame_path)
        row["fake_frame_path"] = str(fake_frame_path)
        row["real_crop_path"] = str(real_crop_path)
        row["fake_crop_path"] = str(fake_crop_path)
        row["status"] = "cropped"
        row["failed_reason"] = ""
        write_manifest(manifest_path, rows)


def mark_failed(row, reason):
    row["status"] = "failed"
    row["failed_reason"] = reason


def run_command(cmd, cwd, dry_run=False):
    if dry_run:
        print("[DRY-RUN]", " ".join(str(x) for x in cmd))
        return
    subprocess.run([str(x) for x in cmd], cwd=str(cwd), check=True)


def optimizer_output_dir(output_parent, crop_path):
    return Path(output_parent) / Path(crop_path).name


def run_reconstructions(rows, args, manifest_path):
    optimizer_py = Path(args.nextface_dir) / "optimizer.py"
    for row in tqdm(rows, desc="NextFace reconstructions"):
        if row.get("status") == "failed":
            continue

        for label in ("real", "fake"):
            crop_path = row.get(f"{label}_crop_path")
            if not crop_path:
                mark_failed(row, f"{label}_crop_missing")
                break

            recon_parent = Path(args.output_root) / "recon" / row["dataset"] / row["pair_id"] / label
            recon_dir = optimizer_output_dir(recon_parent, crop_path)
            final_recon = recon_dir / "finalReconstruction_0.png"
            if not final_recon.exists():
                recon_parent.mkdir(parents=True, exist_ok=True)
                cmd = [
                    args.python_bin,
                    optimizer_py,
                    "--input",
                    crop_path,
                    "--output",
                    recon_parent,
                    "--config",
                    args.optim_config,
                ]
                try:
                    run_command(cmd, args.nextface_dir, dry_run=args.dry_run)
                except subprocess.CalledProcessError as exc:
                    mark_failed(row, f"{label}_reconstruction_failed:{exc.returncode}")
                    break

            row[f"{label}_recon_dir"] = str(recon_dir)

        if row.get("status") != "failed":
            row["status"] = "reconstructed"
            row["failed_reason"] = ""
        write_manifest(manifest_path, rows)


def run_error_maps(rows, args, manifest_path):
    error_script = Path(args.nextface_dir) / "make_reconstruction_error_uv.py"
    uv_pkl = Path(args.nextface_dir) / "baselMorphableModel" / "uvParametrization.1024.pickle"

    for row in tqdm(rows, desc="UV error maps"):
        if row.get("status") == "failed":
            continue

        for label in ("real", "fake"):
            crop_path = Path(row.get(f"{label}_crop_path", ""))
            recon_dir = Path(row.get(f"{label}_recon_dir", ""))
            out_dir = Path(args.output_root) / "error_maps" / row["dataset"] / row["pair_id"] / label
            expected = out_dir / "error_uv_gray.png"
            if not expected.exists():
                cmd = [
                    args.python_bin,
                    error_script,
                    "--input",
                    crop_path,
                    "--reconstruction",
                    recon_dir / "finalReconstruction_0.png",
                    "--obj",
                    recon_dir / "mesh0.obj",
                    "--stage-pkl",
                    recon_dir / "checkpoints" / "stage3_output.pickle",
                    "--uv-pkl",
                    uv_pkl,
                    "--out-dir",
                    out_dir,
                    "--z-tolerance",
                    args.z_tolerance,
                    "--normal-threshold",
                    args.normal_threshold,
                    "--alpha-threshold",
                    args.alpha_threshold,
                    "--mask-erosion",
                    args.mask_erosion,
                ]
                try:
                    run_command(cmd, args.nextface_dir, dry_run=args.dry_run)
                except subprocess.CalledProcessError as exc:
                    mark_failed(row, f"{label}_error_map_failed:{exc.returncode}")
                    break

            row[f"{label}_error_dir"] = str(out_dir)

        if row.get("status") != "failed":
            pair_error_maps(row, args)
            row["status"] = "error_mapped"
            row["failed_reason"] = ""
        write_manifest(manifest_path, rows)


def pair_error_maps(row, args):
    real_dir = Path(row["real_error_dir"])
    fake_dir = Path(row["fake_error_dir"])
    paired_dir = Path(args.output_root) / "error_maps" / row["dataset"] / row["pair_id"] / "paired"
    paired_dir.mkdir(parents=True, exist_ok=True)

    real_gray = cv2.imread(str(real_dir / "error_uv_gray.png"), cv2.IMREAD_GRAYSCALE)
    fake_gray = cv2.imread(str(fake_dir / "error_uv_gray.png"), cv2.IMREAD_GRAYSCALE)
    real_mask = cv2.imread(str(real_dir / "visible_mask.png"), cv2.IMREAD_GRAYSCALE)
    fake_mask = cv2.imread(str(fake_dir / "visible_mask.png"), cv2.IMREAD_GRAYSCALE)

    if real_gray is None or fake_gray is None or real_mask is None or fake_mask is None:
        mark_failed(row, "paired_error_inputs_missing")
        return

    valid = (real_mask > 0) & (fake_mask > 0)
    paired = np.abs(fake_gray.astype(np.int16) - real_gray.astype(np.int16)).astype(np.uint8)
    paired[~valid] = 0
    cv2.imwrite(str(paired_dir / "paired_abs_error_gray.png"), paired)
    cv2.imwrite(str(paired_dir / "paired_visible_mask.png"), valid.astype(np.uint8) * 255)
    row["paired_error_dir"] = str(paired_dir)


def build_face_app(args):
    add_import_paths(args.select_best_dir)
    from insightface.app import FaceAnalysis

    app = FaceAnalysis(name="buffalo_l")
    app.prepare(ctx_id=-1 if args.cpu else 0, det_size=(640, 640))
    return app


def parse_args():
    parser = argparse.ArgumentParser(
        description="Build matched real/fake NextFace UV error maps for capstone experiments."
    )
    parser.add_argument("--output-root", default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--total-images", type=int, default=500, help="Total cropped images. Must be even; 500 means 250 matched pairs.")
    parser.add_argument("--celeb-pairs", type=int, default=125, help="Number of Celeb-DF matched pairs inside total_images / 2.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--top-m", type=int, default=5)
    parser.add_argument("--sample-interval", type=int, default=5)
    parser.add_argument("--max-frame-samples", type=int, default=40, help="Maximum sampled frames per fake video during best-frame search. Use 0 to scan all sampled frames.")
    parser.add_argument("--min-gap", type=int, default=15)
    parser.add_argument("--max-fakes-per-real", type=int, default=1)
    parser.add_argument("--crop-margin", type=float, default=0.3)
    parser.add_argument("--output-size", type=int, default=256)
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--skip-recon", action="store_true")
    parser.add_argument("--skip-error", action="store_true")

    parser.add_argument("--nextface-dir", default=DEFAULT_NEXTFACE_DIR)
    parser.add_argument("--select-best-dir", default=DEFAULT_SELECT_BEST_DIR)
    parser.add_argument("--optim-config", default="/home/yerin/NextFace-map1024/optimConfig.ini")
    parser.add_argument("--python-bin", default=sys.executable, help="Python executable used for optimizer.py and make_reconstruction_error_uv.py subprocesses.")

    parser.add_argument("--celeb-real-root", default="/mnt/SSD/yerin/datasets/Celeb-DF-v2/Celeb-real")
    parser.add_argument("--celeb-fake-root", default="/mnt/SSD/yerin/datasets/Celeb-DF-v2/Celeb-synthesis")
    parser.add_argument("--ffpp-real-root", default="/mnt/SSD/yerin/datasets/FaceForensics++_c23/original_sequences/youtube/c23/videos")
    parser.add_argument("--ffpp-fake-root", default="/mnt/SSD/yerin/datasets/FaceForensics++_c23/manipulated_sequences")
    parser.add_argument(
        "--ffpp-methods",
        nargs="+",
        default=["Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures"],
    )

    parser.add_argument("--z-tolerance", default="2.0")
    parser.add_argument("--normal-threshold", default="0.0")
    parser.add_argument("--alpha-threshold", default="0.5")
    parser.add_argument("--mask-erosion", default="11")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.total_images % 2 != 0:
        raise ValueError("--total-images must be even because every pair has one real and one fake image.")

    total_pairs = args.total_images // 2
    if args.celeb_pairs < 0 or args.celeb_pairs > total_pairs:
        raise ValueError("--celeb-pairs must be between 0 and total_images / 2.")

    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    manifest_path = output_root / "manifest.csv"

    app = build_face_app(args)

    if args.resume and manifest_path.exists():
        rows = read_manifest(manifest_path)
    else:
        rows = build_video_pairs(args, app)
        write_manifest(manifest_path, rows)

    prepare_frames_and_crops(rows, args, app, manifest_path)

    if not args.skip_recon:
        run_reconstructions(rows, args, manifest_path)

    if not args.skip_error:
        run_error_maps(rows, args, manifest_path)

    done = sum(1 for row in rows if row.get("status") == "error_mapped")
    failed = sum(1 for row in rows if row.get("status") == "failed")
    print(f"manifest: {manifest_path}")
    print(f"completed pairs: {done}")
    print(f"failed pairs: {failed}")


if __name__ == "__main__":
    main()
