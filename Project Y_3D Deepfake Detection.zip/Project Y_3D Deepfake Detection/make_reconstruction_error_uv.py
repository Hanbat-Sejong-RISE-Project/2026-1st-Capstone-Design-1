import argparse
import os
import pickle

import cv2
import numpy as np
from PIL import Image


def load_obj_vertices_faces(obj_path):
    vertices = []
    faces = []

    with open(obj_path, "r") as f:
        for line in f:
            line = line.strip()
            if line.startswith("v "):
                parts = line.split()
                vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
            elif line.startswith("f "):
                face = []
                for part in line.split()[1:]:
                    face.append(int(part.split("/")[0]) - 1)
                if len(face) == 3:
                    faces.append(face)

    return np.asarray(vertices, dtype=np.float32), np.asarray(faces, dtype=np.int64)


def rasterize_z_buffer(projected_vertices, z_values, faces, width, height):
    z_buffer = np.full((height, width), np.inf, dtype=np.float32)

    for face in faces:
        tri = projected_vertices[face]
        tri_z = z_values[face]

        min_x = max(int(np.floor(tri[:, 0].min())), 0)
        max_x = min(int(np.ceil(tri[:, 0].max())), width - 1)
        min_y = max(int(np.floor(tri[:, 1].min())), 0)
        max_y = min(int(np.ceil(tri[:, 1].max())), height - 1)
        if min_x > max_x or min_y > max_y:
            continue

        x0, y0 = tri[0]
        x1, y1 = tri[1]
        x2, y2 = tri[2]
        denom = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        if abs(denom) < 1e-8:
            continue

        grid_x, grid_y = np.meshgrid(
            np.arange(min_x, max_x + 1, dtype=np.float32) + 0.5,
            np.arange(min_y, max_y + 1, dtype=np.float32) + 0.5,
        )
        w0 = ((y1 - y2) * (grid_x - x2) + (x2 - x1) * (grid_y - y2)) / denom
        w1 = ((y2 - y0) * (grid_x - x2) + (x0 - x2) * (grid_y - y2)) / denom
        w2 = 1.0 - w0 - w1

        inside = (w0 >= -1e-4) & (w1 >= -1e-4) & (w2 >= -1e-4)
        if not np.any(inside):
            continue

        z = w0 * tri_z[0] + w1 * tri_z[1] + w2 * tri_z[2]
        z_view = z_buffer[min_y:max_y + 1, min_x:max_x + 1]
        update = inside & (z < z_view)
        z_view[update] = z[update]

    return z_buffer


def load_rgb_float(path, width, height):
    image = Image.open(path).convert("RGB")
    image = np.asarray(image).astype(np.float32) / 255.0
    if image.shape[1] != width or image.shape[0] != height:
        image = cv2.resize(image, (width, height), interpolation=cv2.INTER_LINEAR)
    return image


def load_rgba_float(path, width, height):
    image = Image.open(path).convert("RGBA")
    image = np.asarray(image).astype(np.float32) / 255.0
    if image.shape[1] != width or image.shape[0] != height:
        image = cv2.resize(image, (width, height), interpolation=cv2.INTER_LINEAR)
    return image[..., :3], image[..., 3]


def save_rgb(path, image):
    image_u8 = (np.clip(image, 0.0, 1.0) * 255).astype(np.uint8)
    cv2.imwrite(path, cv2.cvtColor(image_u8, cv2.COLOR_RGB2BGR))


def repair_center_seam_mask(mask, seam_width):
    if seam_width <= 0:
        return mask

    repaired = mask.copy()
    height, width = repaired.shape
    center = width // 2
    half = seam_width // 2
    start = max(center - half, 1)
    end = min(center + half + 1, width - 1)
    if start >= end:
        return repaired

    left_col = max(start - 1, 0)
    right_col = min(end, width - 1)
    bridge = repaired[:, left_col] & repaired[:, right_col]
    repaired[:, start:end] = np.repeat(bridge[:, None], end - start, axis=1)
    return repaired


def erode_mask(mask, kernel_size, iterations=1):
    if kernel_size <= 1 or iterations <= 0:
        return mask

    if kernel_size % 2 == 0:
        kernel_size += 1

    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    eroded = cv2.erode(mask.astype(np.uint8), kernel, iterations=iterations)
    return eroded.astype(bool)


def build_normal_facing_map(vertices, faces, uv_map_faces, uv_xy, uv_res):
    face_vertex_idx = faces[uv_map_faces]
    tri = vertices[face_vertex_idx]

    normals = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    normal_norm = np.linalg.norm(normals, axis=1, keepdims=True)
    normals = normals / np.maximum(normal_norm, 1e-8)

    centers = tri.mean(axis=1)
    view_dirs = -centers
    view_norm = np.linalg.norm(view_dirs, axis=1, keepdims=True)
    view_dirs = view_dirs / np.maximum(view_norm, 1e-8)

    facing = np.sum(normals * view_dirs, axis=1)
    if np.nanmedian(facing) < 0.0:
        facing = -facing

    facing_raw = np.full((uv_res, uv_res), -np.inf, dtype=np.float32)
    facing_raw[uv_xy[:, 0], uv_xy[:, 1]] = facing.astype(np.float32)
    return np.flip(facing_raw.T, axis=0).copy()


def build_uv_remap_and_mask(
    vertices,
    faces,
    stage,
    uv_data,
    z_tolerance,
    normal_threshold,
):
    uv_faces_w = uv_data["uvFaces"].astype(np.float32)
    uv_map_faces = uv_data["uvMapFaces"].astype(np.int64)
    uv_xy = uv_data["uvXYMap"].astype(np.int64)
    uv_valid = uv_data["uvValidUVMap"].astype(bool)
    uv_res = int(uv_data["uvResolution"])

    focal = float(stage["vFocals"][0])
    width = int(stage["screenWidth"])
    height = int(stage["screenHeight"])

    x = vertices[:, 0]
    y = vertices[:, 1]
    z = vertices[:, 2]
    proj_x = focal * (x / z) + width / 2.0
    proj_y = focal * (y / z) + height / 2.0
    projected_vertices = np.stack([proj_x, proj_y], axis=1).astype(np.float32)
    z_buffer = rasterize_z_buffer(projected_vertices, z, faces, width, height)

    face_vertex_idx = faces[uv_map_faces]
    tri_proj = projected_vertices[face_vertex_idx]
    src_xy = np.sum(tri_proj * uv_faces_w[:, :, None], axis=1)
    tri_z = z[face_vertex_idx]
    src_z = np.sum(tri_z * uv_faces_w, axis=1)

    src_x = src_xy[:, 0].astype(np.float32)
    src_y = src_xy[:, 1].astype(np.float32)
    sample_x = np.rint(src_x).astype(np.int64)
    sample_y = np.rint(src_y).astype(np.int64)
    inside_image = (
        (sample_x >= 0)
        & (sample_x < width)
        & (sample_y >= 0)
        & (sample_y < height)
    )

    visible_texels = np.zeros_like(inside_image)
    visible_z = z_buffer[sample_y[inside_image], sample_x[inside_image]]
    visible_texels[inside_image] = src_z[inside_image] <= visible_z + z_tolerance

    map_x_raw = np.full((uv_res, uv_res), -1, dtype=np.float32)
    map_y_raw = np.full((uv_res, uv_res), -1, dtype=np.float32)
    visible_raw = np.zeros((uv_res, uv_res), dtype=bool)

    uv_x = uv_xy[:, 0]
    uv_y = uv_xy[:, 1]
    map_x_raw[uv_x, uv_y] = src_x
    map_y_raw[uv_x, uv_y] = src_y
    visible_raw[uv_x, uv_y] = visible_texels

    # Match MorphableModel.generateTextureFromAlbedo() output layout:
    # raw[uv_x, uv_y] -> raw.T -> vertical flip.
    map_x = np.flip(map_x_raw.T, axis=0).copy()
    map_y = np.flip(map_y_raw.T, axis=0).copy()
    uv_valid = np.flip(uv_valid.T, axis=0).copy()
    visible = np.flip(visible_raw.T, axis=0).copy()
    normal_facing = build_normal_facing_map(vertices, faces, uv_map_faces, uv_xy, uv_res)
    compare_mask = uv_valid & visible & (normal_facing >= normal_threshold)

    return map_x, map_y, compare_mask, width, height, uv_res


def unwrap_image_to_uv(image, map_x, map_y, compare_mask):
    uv = cv2.remap(
        image,
        map_x,
        map_y,
        interpolation=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )
    uv[~compare_mask] = 0.0
    return uv


def unwrap_scalar_to_uv(image, map_x, map_y):
    return cv2.remap(
        image.astype(np.float32),
        map_x,
        map_y,
        interpolation=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )


def fill_center_seam(image):
    filled = image.copy()
    half_res = filled.shape[1] // 2
    filled[:, half_res] = 0.5 * (filled[:, half_res - 1] + filled[:, half_res + 1])
    return filled


def parse_args():
    parser = argparse.ArgumentParser(
        description="Create UV-space error map between input image and finalReconstruction_0.png."
    )
    parser.add_argument("--input", default="/home/yerin/NextFace-map1024/input/s4.png")
    parser.add_argument("--reconstruction", default="/home/yerin/NextFace-map1024/output/s4.png/finalReconstruction_0.png")
    parser.add_argument("--obj", default="/home/yerin/NextFace-map1024/output/s4.png/mesh0.obj")
    parser.add_argument("--stage-pkl", default="/home/yerin/NextFace-map1024/output/s4.png/checkpoints/stage3_output.pickle")
    parser.add_argument("--uv-pkl", default="/home/yerin/NextFace-map1024/baselMorphableModel/uvParametrization.1024.pickle")
    parser.add_argument("--out-dir", default="/home/yerin/NextFace-map1024/recon_uv_error_test")
    parser.add_argument("--z-tolerance", type=float, default=2.0)
    parser.add_argument(
        "--normal-threshold",
        type=float,
        default=0.0,
        help="Keep UV texels whose face normal points toward the camera by at least this cosine value. Use 0.3 for a more aggressive mask.",
    )
    parser.add_argument(
        "--alpha-threshold",
        type=float,
        default=0.5,
        help="Keep UV texels only where finalReconstruction alpha remains above this value. Use 0 to disable.",
    )
    parser.add_argument(
        "--seam-fill-width",
        type=int,
        default=3,
        help="Width around the UV center seam to bridge before mask erosion. Use 0 to disable.",
    )
    parser.add_argument(
        "--mask-erosion",
        type=int,
        default=11,
        help="Ellipse kernel size for shrinking the compare mask in UV space. Use 0 or 1 to disable.",
    )
    parser.add_argument(
        "--mask-erosion-iterations",
        type=int,
        default=1,
        help="Number of erosion passes applied to the compare mask.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    with open(args.stage_pkl, "rb") as f:
        stage = pickle.load(f)
    with open(args.uv_pkl, "rb") as f:
        uv_data = pickle.load(f)

    vertices, faces = load_obj_vertices_faces(args.obj)
    map_x, map_y, compare_mask, width, height, uv_res = build_uv_remap_and_mask(
        vertices,
        faces,
        stage,
        uv_data,
        args.z_tolerance,
        args.normal_threshold,
    )

    original = load_rgb_float(args.input, width, height)
    reconstruction, reconstruction_alpha = load_rgba_float(args.reconstruction, width, height)

    if args.alpha_threshold > 0.0:
        reconstruction_alpha_uv = unwrap_scalar_to_uv(reconstruction_alpha, map_x, map_y)
        compare_mask &= reconstruction_alpha_uv >= args.alpha_threshold

    compare_mask = repair_center_seam_mask(compare_mask, args.seam_fill_width)
    compare_mask = erode_mask(compare_mask, args.mask_erosion, args.mask_erosion_iterations)
    compare_mask = repair_center_seam_mask(compare_mask, args.seam_fill_width)

    original_uv = unwrap_image_to_uv(original, map_x, map_y, compare_mask)
    reconstruction_uv = unwrap_image_to_uv(reconstruction, map_x, map_y, compare_mask)
    original_uv = fill_center_seam(original_uv)
    reconstruction_uv = fill_center_seam(reconstruction_uv)
    original_uv[~compare_mask] = 0.0
    reconstruction_uv[~compare_mask] = 0.0

    error_rgb = np.abs(original_uv - reconstruction_uv)
    error_gray = error_rgb.mean(axis=2)
    error_gray[~compare_mask] = 0.0
    error_rgb = fill_center_seam(error_rgb)
    error_gray = fill_center_seam(error_gray)
    error_rgb[~compare_mask] = 0.0
    error_gray[~compare_mask] = 0.0

    save_rgb(os.path.join(args.out_dir, "original_uv.png"), original_uv)
    save_rgb(os.path.join(args.out_dir, "reconstruction_uv.png"), reconstruction_uv)
    save_rgb(os.path.join(args.out_dir, "error_uv_rgb.png"), error_rgb)
    cv2.imwrite(
        os.path.join(args.out_dir, "error_uv_gray.png"),
        (np.clip(error_gray, 0.0, 1.0) * 255).astype(np.uint8),
    )
    cv2.imwrite(
        os.path.join(args.out_dir, "visible_mask.png"),
        compare_mask.astype(np.uint8) * 255,
    )

    print("vertices:", vertices.shape)
    print("faces:", faces.shape)
    print("screen:", width, height)
    print("uv_res:", uv_res)
    print("saved to:", args.out_dir)


if __name__ == "__main__":
    main()
