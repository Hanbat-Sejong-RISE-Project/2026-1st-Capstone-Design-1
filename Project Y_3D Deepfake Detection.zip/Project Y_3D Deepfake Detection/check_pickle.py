# import pickle

# pkl_path = "/home/yerin/NextFace-map1024/baselMorphableModel/uvParametrization.1024.pickle"

# with open(pkl_path, "rb") as f:
#     data = pickle.load(f)

# print(type(data))

# if isinstance(data, dict):
#     print(data.keys())

#     for k, v in data.items():
#         print("-----")
#         print(k, type(v))
#         try:
#             print("shape:", v.shape)
#         except:
#             pass
# else:
#     print(data)


# import pickle
# import numpy as np

# pkl_path = "/home/yerin/NextFace-map1024/baselMorphableModel/uvParametrization.1024.pickle"

# with open(pkl_path, "rb") as f:
#     data = pickle.load(f)

# print("type:", type(data))

# if isinstance(data, dict):
#     print("keys:")
#     print(data.keys())

#     for k, v in data.items():
#         print("-----")
#         print(k, type(v))
#         if hasattr(v, "shape"):
#             print("shape:", v.shape)
#         elif isinstance(v, list):
#             print("len:", len(v))
# else:
#     print(data)


# import pickle
# import numpy as np

# pkl_path = "/home/yerin/NextFace-map1024/baselMorphableModel/uvParametrization.1024.pickle"

# with open(pkl_path, "rb") as f:
#     data = pickle.load(f)

# for k, v in data.items():
#     print("====", k, "====")
#     print(type(v))

#     if isinstance(v, np.ndarray):
#         print("shape:", v.shape)
#         print("dtype:", v.dtype)
#         print("min:", np.nanmin(v))
#         print("max:", np.nanmax(v))
#         print("first 5:", v.reshape(-1, v.shape[-1])[:5] if v.ndim >= 2 else v[:5])
#     else:
#         print(v)



# import pickle
# import numpy as np
# import torch

# pkl_path = "output/save_fianlrecon/emily.png/checkpoints/stage3_output.pickle"

# with open(pkl_path, "rb") as f:
#     data = pickle.load(f)

# print("type:", type(data))

# def describe(v):
#     if isinstance(v, np.ndarray):
#         return f"np.ndarray shape={v.shape}, dtype={v.dtype}, min={np.nanmin(v)}, max={np.nanmax(v)}"
#     elif torch.is_tensor(v):
#         return f"torch.Tensor shape={tuple(v.shape)}, dtype={v.dtype}, min={v.min().item()}, max={v.max().item()}"
#     elif isinstance(v, dict):
#         return f"dict keys={list(v.keys())}"
#     elif isinstance(v, list):
#         return f"list len={len(v)}"
#     else:
#         return f"{type(v)} value={v}"

# if isinstance(data, dict):
#     print("keys:", data.keys())
#     for k, v in data.items():
#         print("====", k, "====")
#         try:
#             print(describe(v))
#         except Exception as e:
#             print(type(v), "describe error:", e)
# else:
#     print(data)

# for pkl_path in [
#     "output/save_fianlrecon/emily.png/checkpoints/stage1_output.pickle",
#     "output/save_fianlrecon/emily.png/checkpoints/stage2_output.pickle",
#     "output/save_fianlrecon/emily.png/checkpoints/stage3_output.pickle",
# ]:
#     print("\n\n########################")
#     print(pkl_path)
#     print("########################")

#     with open(pkl_path, "rb") as f:
#         data = pickle.load(f)

#     print("type:", type(data))
#     if isinstance(data, dict):
#         print("keys:", data.keys())
#         for k, v in data.items():
#             print("====", k, "====")
#             if isinstance(v, np.ndarray):
#                 print("np", v.shape, v.dtype, np.nanmin(v), np.nanmax(v))
#             elif torch.is_tensor(v):
#                 print("torch", tuple(v.shape), v.dtype, v.min().item(), v.max().item())
#             else:
#                 print(type(v), v if isinstance(v, (int, float, str)) else "")



import os
import pickle
import numpy as np
import cv2
from PIL import Image


# =========================
# path 설정
# =========================
input_img_path = "/home/yerin/NextFace-map1024/input/s4.png"  # 실제 원본 이미지 경로로 바꿔야 함
obj_path = "/home/yerin/NextFace-map1024/output/s4.png/mesh0.obj"
stage_pkl_path = "/home/yerin/NextFace-map1024/output/s4.png/checkpoints/stage3_output.pickle"
uv_pkl_path = "baselMorphableModel/uvParametrization.1024.pickle"

out_dir = "uv_error_test"
os.makedirs(out_dir, exist_ok=True)


# =========================
# OBJ parser
# =========================
def load_obj_vertices_faces(obj_path):
    vertices = []
    faces = []

    with open(obj_path, "r") as f:
        for line in f:
            line = line.strip()

            if line.startswith("v "):
                parts = line.split()
                vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])

            elif line.startswith("f "):
                parts = line.split()[1:]
                face = []
                for p in parts:
                    # 가능한 형태:
                    # f 1 2 3
                    # f 1/1 2/2 3/3
                    # f 1/1/1 2/2/2 3/3/3
                    v_idx = int(p.split("/")[0]) - 1  # OBJ는 1-index
                    face.append(v_idx)

                if len(face) == 3:
                    faces.append(face)

    return np.asarray(vertices, dtype=np.float32), np.asarray(faces, dtype=np.int64)


def rasterize_visible_faces(projected_vertices, z_values, faces, width, height):
    z_buffer = np.full((height, width), np.inf, dtype=np.float32)
    face_buffer = np.full((height, width), -1, dtype=np.int64)

    for face_id, face in enumerate(faces):
        tri = projected_vertices[face]
        tri_z = z_values[face]

        min_x = max(int(np.floor(tri[:, 0].min())), 0)
        max_x = min(int(np.ceil(tri[:, 0].max())), width - 1)
        min_y = max(int(np.floor(tri[:, 1].min())), 0)
        max_y = min(int(np.ceil(tri[:, 1].max())), height - 1)
        if min_x > max_x or min_y > max_y:
            continue

        x0, y0 = tri[0]
        x1, y1 = tri[1]
        x2, y2 = tri[2]
        denom = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        if abs(denom) < 1e-8:
            continue

        grid_x, grid_y = np.meshgrid(
            np.arange(min_x, max_x + 1, dtype=np.float32) + 0.5,
            np.arange(min_y, max_y + 1, dtype=np.float32) + 0.5,
        )
        w0 = ((y1 - y2) * (grid_x - x2) + (x2 - x1) * (grid_y - y2)) / denom
        w1 = ((y2 - y0) * (grid_x - x2) + (x0 - x2) * (grid_y - y2)) / denom
        w2 = 1.0 - w0 - w1

        inside = (w0 >= -1e-4) & (w1 >= -1e-4) & (w2 >= -1e-4)
        if not np.any(inside):
            continue

        z = w0 * tri_z[0] + w1 * tri_z[1] + w2 * tri_z[2]
        z_view = z_buffer[min_y:max_y + 1, min_x:max_x + 1]
        f_view = face_buffer[min_y:max_y + 1, min_x:max_x + 1]
        update = inside & (z < z_view)
        z_view[update] = z[update]
        f_view[update] = face_id

    return z_buffer, face_buffer


# =========================
# load
# =========================
with open(stage_pkl_path, "rb") as f:
    stage = pickle.load(f)

with open(uv_pkl_path, "rb") as f:
    uv_data = pickle.load(f)

vertices, faces = load_obj_vertices_faces(obj_path)

print("vertices:", vertices.shape)
print("faces:", faces.shape)

uv_faces_w = uv_data["uvFaces"].astype(np.float32)       # barycentric weight, [N, 3]
uv_map_faces = uv_data["uvMapFaces"].astype(np.int64)    # face id, [N]
uv_xy = uv_data["uvXYMap"].astype(np.int64)              # UV pixel xy, [N, 2]
uv_valid = uv_data["uvValidUVMap"]

uv_res = int(uv_data["uvResolution"])

focal = float(stage["vFocals"][0])
W = int(stage["screenWidth"])
H = int(stage["screenHeight"])

print("uv_res:", uv_res)
print("screen:", W, H)
print("focal:", focal)


# =========================
# original image load
# =========================
img = Image.open(input_img_path).convert("RGB")
img = np.asarray(img).astype(np.float32) / 255.0

# fitting이 256x256 기준이므로 원본도 맞춰줌
if img.shape[1] != W or img.shape[0] != H:
    img = cv2.resize(img, (W, H), interpolation=cv2.INTER_LINEAR)

print("input image:", img.shape)


# =========================
# project 3D vertices to image coordinates
# =========================
X = vertices[:, 0]
Y = vertices[:, 1]
Z = vertices[:, 2]

proj_x = focal * (X / Z) + W / 2.0
proj_y = focal * (Y / Z) + H / 2.0

projected_vertices = np.stack([proj_x, proj_y], axis=1).astype(np.float32)

print("projected x range:", projected_vertices[:, 0].min(), projected_vertices[:, 0].max())
print("projected y range:", projected_vertices[:, 1].min(), projected_vertices[:, 1].max())

visible_z_buffer, visible_face_buffer = rasterize_visible_faces(projected_vertices, Z, faces, W, H)


# =========================
# UV pixel -> source image coordinate
# =========================
face_vertex_idx = faces[uv_map_faces]  # [N, 3]
tri_proj = projected_vertices[face_vertex_idx]  # [N, 3, 2]

src_xy = np.sum(tri_proj * uv_faces_w[:, :, None], axis=1)  # [N, 2]
tri_z = Z[face_vertex_idx]
src_z = np.sum(tri_z * uv_faces_w, axis=1)

src_x = src_xy[:, 0].astype(np.float32)
src_y = src_xy[:, 1].astype(np.float32)

sample_x = np.rint(src_x).astype(np.int64)
sample_y = np.rint(src_y).astype(np.int64)
inside_image = (sample_x >= 0) & (sample_x < W) & (sample_y >= 0) & (sample_y < H)

visible_uv_raw = np.zeros((uv_res, uv_res), dtype=bool)
visible_texels = np.zeros_like(inside_image)
visible_z = visible_z_buffer[sample_y[inside_image], sample_x[inside_image]]
visible_texels[inside_image] = src_z[inside_image] <= visible_z + 2.0


# =========================
# bilinear sampling by cv2.remap
# =========================
# remap은 map_x, map_y가 image 크기여야 해서 valid pixel 위치에만 좌표를 넣음
map_x = np.full((uv_res, uv_res), -1, dtype=np.float32)
map_y = np.full((uv_res, uv_res), -1, dtype=np.float32)

uv_x = uv_xy[:, 0]
uv_y = uv_xy[:, 1]

map_x[uv_x, uv_y] = src_x
map_y[uv_x, uv_y] = src_y
visible_uv_raw[uv_x, uv_y] = visible_texels

# MorphableModel.generateTextureFromAlbedo() writes uvXYMap into a raw texture as
# [uv_x, uv_y], then returns raw.permute(1, 0).flip(0). Match that final layout
# before comparing against vEnhancedDiffuse.
map_x = np.flip(map_x.T, axis=0).copy()
map_y = np.flip(map_y.T, axis=0).copy()
uv_valid = np.flip(uv_valid.T, axis=0).copy()
visible_uv = np.flip(visible_uv_raw.T, axis=0).copy()
compare_mask = uv_valid & visible_uv

original_uv = cv2.remap(
    img,
    map_x,
    map_y,
    interpolation=cv2.INTER_LINEAR,
    borderMode=cv2.BORDER_CONSTANT,
    borderValue=0,
)

# valid 영역 중 원본 카메라에서 실제로 보인 texel만 남김
original_uv_all = original_uv.copy()
original_uv[~compare_mask] = 0.0


# =========================
# diffuse map과 error map
# =========================
diffuse_uv = stage["vEnhancedDiffuse"][0].astype(np.float32)
diffuse_uv = np.clip(diffuse_uv, 0.0, 1.0)

error_map = np.abs(original_uv - diffuse_uv)
error_gray = error_map.mean(axis=2)

# 안 보이는 영역은 error 계산에서 제외
diffuse_uv[~compare_mask] = 0.0
error_map[~compare_mask] = 0.0
error_gray[~compare_mask] = 0.0


# =========================
# save
# =========================
cv2.imwrite(
    os.path.join(out_dir, "original_uv.png"),
    cv2.cvtColor((np.clip(original_uv, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
)

cv2.imwrite(
    os.path.join(out_dir, "original_uv_all_projected.png"),
    cv2.cvtColor((np.clip(original_uv_all, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
)

cv2.imwrite(
    os.path.join(out_dir, "visible_mask.png"),
    (compare_mask.astype(np.uint8) * 255)
)

cv2.imwrite(
    os.path.join(out_dir, "diffuse_uv.png"),
    cv2.cvtColor((np.clip(diffuse_uv, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
)

cv2.imwrite(
    os.path.join(out_dir, "error_map_rgb.png"),
    cv2.cvtColor((np.clip(error_map, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
)

cv2.imwrite(
    os.path.join(out_dir, "error_map_gray.png"),
    (np.clip(error_gray, 0, 1) * 255).astype(np.uint8)
)

print("saved to:", out_dir)
