-- 목적: Transformer/N-HiTS 학습에 사용할 15분 sequence feature table을 만든다.
-- v1.3.8 보강 기준으로 lag / rolling / ramp / calendar feature를 포함한다.

CREATE OR REPLACE TABLE `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.train_sequence_15m_base_v1` AS
WITH base AS (
  SELECT
    base_datetime,
    demand_mw
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_15m_v`
  WHERE demand_mw IS NOT NULL
), lagged AS (
  SELECT
    base_datetime,
    demand_mw,
    LAG(demand_mw, 1) OVER (ORDER BY base_datetime) AS target_lag_1,
    LAG(demand_mw, 4) OVER (ORDER BY base_datetime) AS target_lag_4,
    LAG(demand_mw, 96) OVER (ORDER BY base_datetime) AS target_lag_96,
    AVG(demand_mw) OVER (ORDER BY base_datetime ROWS BETWEEN 4 PRECEDING AND 1 PRECEDING) AS target_roll_mean_4,
    AVG(demand_mw) OVER (ORDER BY base_datetime ROWS BETWEEN 12 PRECEDING AND 1 PRECEDING) AS target_roll_mean_12,
    STDDEV_SAMP(demand_mw) OVER (ORDER BY base_datetime ROWS BETWEEN 12 PRECEDING AND 1 PRECEDING) AS target_roll_std_12,
    AVG(demand_mw) OVER (ORDER BY base_datetime ROWS BETWEEN 96 PRECEDING AND 1 PRECEDING) AS target_roll_mean_96,
    STDDEV_SAMP(demand_mw) OVER (ORDER BY base_datetime ROWS BETWEEN 96 PRECEDING AND 1 PRECEDING) AS target_roll_std_96,
    demand_mw - LAG(demand_mw, 1) OVER (ORDER BY base_datetime) AS target_ramp_1,
    demand_mw - LAG(demand_mw, 4) OVER (ORDER BY base_datetime) AS target_ramp_4,
    CAST(EXTRACT(HOUR FROM base_datetime) AS FLOAT64) AS hour,
    CAST(MOD(EXTRACT(DAYOFWEEK FROM base_datetime) + 5, 7) AS FLOAT64) AS dayofweek,
    CAST(EXTRACT(MONTH FROM base_datetime) AS FLOAT64) AS month,
    CAST(DIV(EXTRACT(HOUR FROM base_datetime) * 60 + EXTRACT(MINUTE FROM base_datetime), 15) AS FLOAT64) AS slot_15m
  FROM base
), featured AS (
  SELECT
    *,
    CASE WHEN dayofweek >= 5 THEN TRUE ELSE FALSE END AS is_weekend,
    SIN(2 * ACOS(-1) * hour / 24) AS hour_sin,
    COS(2 * ACOS(-1) * hour / 24) AS hour_cos,
    SIN(2 * ACOS(-1) * dayofweek / 7) AS dayofweek_sin,
    COS(2 * ACOS(-1) * dayofweek / 7) AS dayofweek_cos,
    SIN(2 * ACOS(-1) * slot_15m / 96) AS quarter_slot_sin,
    COS(2 * ACOS(-1) * slot_15m / 96) AS quarter_slot_cos
  FROM lagged
)
SELECT *
FROM featured
WHERE target_lag_96 IS NOT NULL
  AND target_roll_mean_96 IS NOT NULL
  AND target_roll_std_96 IS NOT NULL
  AND target_ramp_4 IS NOT NULL;

CREATE OR REPLACE TABLE `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.train_transformer_window_index_v1` AS
WITH ordered AS (
  SELECT
    base_datetime,
    ROW_NUMBER() OVER (ORDER BY base_datetime) AS rn
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.train_sequence_15m_base_v1`
), indexed AS (
  SELECT
    base_datetime AS prediction_time,
    rn,
    COUNT(*) OVER () AS total_rows,
    MAX(base_datetime) OVER () AS max_prediction_time
  FROM ordered
)
SELECT
  prediction_time,
  96 AS input_window,
  24 AS horizon,
  CASE
    WHEN prediction_time < TIMESTAMP_SUB(max_prediction_time, INTERVAL 30 DAY) THEN 'train'
    WHEN prediction_time < TIMESTAMP_SUB(max_prediction_time, INTERVAL 14 DAY) THEN 'valid'
    ELSE 'test'
  END AS split
FROM indexed
WHERE rn >= 96
  AND rn + 24 <= total_rows;

CREATE OR REPLACE TABLE `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.train_nhits_long_v1` AS
SELECT
  'kpx_total_demand' AS unique_id,
  base_datetime AS ds,
  demand_mw AS y,
  is_weekend,
  FALSE AS is_holiday,
  hour_sin,
  hour_cos,
  dayofweek_sin,
  dayofweek_cos,
  quarter_slot_sin,
  quarter_slot_cos
FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.train_sequence_15m_base_v1`
WHERE demand_mw IS NOT NULL;
