-- 목적: Looker Studio에서 최신 예측, 최근 run, 성능 KPI를 보기 위한 view를 만든다.

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_latest_forecast_curve` AS
WITH latest AS (
  SELECT
    prediction_time,
    model_version,
    pipeline_run_id,
    MAX(predicted_at) AS run_predicted_at
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.predictions`
  GROUP BY prediction_time, model_version, pipeline_run_id
  QUALIFY ROW_NUMBER() OVER (ORDER BY run_predicted_at DESC, prediction_time DESC) = 1
)
SELECT
  p.prediction_time,
  p.target_time,
  p.horizon_min,
  p.model_version,
  p.pipeline_run_id,
  p.yhat,
  p.prediction_method,
  p.feature_version,
  p.predicted_at
FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.predictions` AS p
JOIN latest AS l
  ON p.prediction_time = l.prediction_time
 AND p.model_version = l.model_version
 AND IFNULL(p.pipeline_run_id, '') = IFNULL(l.pipeline_run_id, '');

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_recent_forecast_runs` AS
WITH recent_runs AS (
  SELECT
    prediction_time,
    model_version,
    pipeline_run_id,
    MAX(predicted_at) AS run_predicted_at
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.predictions`
  GROUP BY prediction_time, model_version, pipeline_run_id
  QUALIFY ROW_NUMBER() OVER (ORDER BY run_predicted_at DESC, prediction_time DESC) <= 10
)
SELECT
  p.prediction_time,
  p.target_time,
  p.horizon_min,
  p.model_version,
  p.pipeline_run_id,
  p.yhat,
  p.feature_version,
  p.predicted_at
FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.predictions` AS p
JOIN recent_runs AS r
  ON p.prediction_time = r.prediction_time
 AND p.model_version = r.model_version
 AND IFNULL(p.pipeline_run_id, '') = IFNULL(r.pipeline_run_id, '');

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_prediction_run_history` AS
SELECT
  pipeline_run_id,
  run_type,
  model_version,
  status,
  gate_status,
  error_message,
  prediction_count,
  started_at,
  ended_at,
  created_at
FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.prediction_run_log`;

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_model_registry` AS
SELECT
  model_version,
  model_type,
  status,
  is_current,
  feature_version,
  valid_wmape,
  test_wmape,
  artifact_uri,
  updated_at
FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.model_registry_control`;

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_page3_latest_complete_run_kpi` AS
SELECT
  prediction_time,
  model_version,
  pipeline_run_id,
  evaluation_status,
  actual_coverage,
  run_wmape,
  run_wmape_pct,
  run_mape,
  run_mape_pct,
  run_mae,
  min_target_time,
  max_target_time,
  evaluated_at
FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_run_level_evaluation_simple`
WHERE evaluation_status = 'COMPLETE'
QUALIFY ROW_NUMBER() OVER (ORDER BY prediction_time DESC) = 1;

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_page3_latest_run_status` AS
SELECT
  prediction_time,
  model_version,
  pipeline_run_id,
  evaluation_status,
  actual_coverage,
  prediction_count,
  valid_actual_count,
  missing_actual_count,
  min_target_time,
  max_target_time,
  evaluated_at
FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_run_level_evaluation_simple`
QUALIFY ROW_NUMBER() OVER (ORDER BY prediction_time DESC) = 1;
