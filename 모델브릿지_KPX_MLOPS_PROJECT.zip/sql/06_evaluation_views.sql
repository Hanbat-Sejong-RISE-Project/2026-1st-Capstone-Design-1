-- 목적: prediction_time 하나를 24-step run으로 보고, 실제값 24개가 모두 붙은 COMPLETE run만 평가한다.

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_looker_run_level_evaluation_simple` AS
WITH actual_cutoff AS (
  SELECT MAX(base_datetime) AS max_actual_time
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_15m_v`
), dedup_predictions AS (
  SELECT *
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.predictions`
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY prediction_time, model_version, pipeline_run_id, horizon_min
    ORDER BY predicted_at DESC, created_at DESC
  ) = 1
), joined AS (
  SELECT
    p.prediction_time,
    p.model_version,
    COALESCE(p.pipeline_run_id, 'unknown') AS pipeline_run_id,
    p.horizon_min,
    p.target_time,
    p.yhat,
    a.demand_mw AS actual_mw,
    CASE WHEN a.demand_mw IS NOT NULL THEN TRUE ELSE FALSE END AS has_actual,
    p.yhat - a.demand_mw AS error,
    ABS(p.yhat - a.demand_mw) AS abs_error,
    SAFE_DIVIDE(ABS(p.yhat - a.demand_mw), NULLIF(ABS(a.demand_mw), 0)) AS ape,
    p.predicted_at,
    p.created_at
  FROM dedup_predictions AS p
  LEFT JOIN `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_15m_v` AS a
    ON a.base_datetime = p.target_time
), summary AS (
  SELECT
    j.prediction_time,
    j.model_version,
    j.pipeline_run_id,
    COUNT(DISTINCT j.horizon_min) AS prediction_count,
    COUNTIF(j.has_actual) AS valid_actual_count,
    COUNTIF(NOT j.has_actual) AS missing_actual_count,
    MIN(j.target_time) AS min_target_time,
    MAX(j.target_time) AS max_target_time,
    MAX(j.predicted_at) AS latest_predicted_at,
    CASE
      WHEN COUNT(DISTINCT j.horizon_min) < 24 THEN 'PREDICTION_INCOMPLETE'
      WHEN MAX(j.target_time) > (SELECT max_actual_time FROM actual_cutoff) THEN 'PENDING'
      WHEN COUNTIF(j.has_actual) < 24 THEN 'ACTUAL_MISSING'
      WHEN COUNTIF(j.has_actual) = 24 THEN 'COMPLETE'
      ELSE 'UNKNOWN'
    END AS evaluation_status,
    CASE WHEN COUNTIF(j.has_actual) = 24 AND COUNT(DISTINCT j.horizon_min) = 24
      THEN SAFE_DIVIDE(SUM(j.abs_error), NULLIF(SUM(ABS(j.actual_mw)), 0)) END AS run_wmape,
    CASE WHEN COUNTIF(j.has_actual) = 24 AND COUNT(DISTINCT j.horizon_min) = 24
      THEN 100 * SAFE_DIVIDE(SUM(j.abs_error), NULLIF(SUM(ABS(j.actual_mw)), 0)) END AS run_wmape_pct,
    CASE WHEN COUNTIF(j.has_actual) = 24 AND COUNT(DISTINCT j.horizon_min) = 24
      THEN AVG(j.abs_error) END AS run_mae,
    CASE WHEN COUNTIF(j.has_actual) = 24 AND COUNT(DISTINCT j.horizon_min) = 24
      THEN AVG(j.ape) END AS run_mape,
    CASE WHEN COUNTIF(j.has_actual) = 24 AND COUNT(DISTINCT j.horizon_min) = 24
      THEN 100 * AVG(j.ape) END AS run_mape_pct
  FROM joined AS j
  GROUP BY j.prediction_time, j.model_version, j.pipeline_run_id
)
SELECT
  prediction_time,
  model_version,
  pipeline_run_id,
  prediction_count,
  valid_actual_count,
  missing_actual_count,
  CONCAT(CAST(valid_actual_count AS STRING), '/24') AS actual_coverage,
  evaluation_status,
  run_wmape,
  run_wmape_pct,
  run_mae,
  run_mape,
  run_mape_pct,
  min_target_time,
  max_target_time,
  latest_predicted_at,
  CURRENT_TIMESTAMP() AS evaluated_at
FROM summary;
