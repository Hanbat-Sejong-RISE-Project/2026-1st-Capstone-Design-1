-- 목적: 같은 base_datetime에 여러 row가 있으면 가장 최근 ingested_at 1건만 silver에 유지한다.
-- 이 쿼리는 raw를 읽기만 하고, review silver에만 쓴다.

CREATE TABLE IF NOT EXISTS `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_5m` (
  base_datetime TIMESTAMP NOT NULL,
  ingested_at TIMESTAMP,
  source_timezone STRING,
  demand_mw FLOAT64,
  is_corrected BOOL,
  quality_flags ARRAY<STRING>,
  source STRING,
  updated_at TIMESTAMP
);

MERGE `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_5m` AS T
USING (
  WITH anchor AS (
    SELECT MAX(base_datetime) AS anchor_ts
    FROM `{{PROJECT_ID}}.{{RAW_DATASET_ID}}.raw_kpx_5m`
  ), ranked AS (
    SELECT
      r.base_datetime,
      r.ingested_at,
      r.source_timezone,
      SAFE_CAST(r.demand_mw AS FLOAT64) AS demand_mw,
      FALSE AS is_corrected,
      ARRAY<STRING>[] AS quality_flags,
      r.source,
      ROW_NUMBER() OVER (
        PARTITION BY r.base_datetime
        ORDER BY r.ingested_at DESC
      ) AS rn
    FROM `{{PROJECT_ID}}.{{RAW_DATASET_ID}}.raw_kpx_5m` AS r
    CROSS JOIN anchor AS a
    WHERE r.base_datetime >= TIMESTAMP_SUB(a.anchor_ts, INTERVAL 90 DAY)
      AND r.base_datetime <= a.anchor_ts
  )
  SELECT
    base_datetime, ingested_at, source_timezone, demand_mw,
    is_corrected, quality_flags, source
  FROM ranked
  WHERE rn = 1
) AS S
ON T.base_datetime = S.base_datetime
WHEN MATCHED THEN UPDATE SET
  ingested_at = S.ingested_at,
  source_timezone = S.source_timezone,
  demand_mw = S.demand_mw,
  is_corrected = S.is_corrected,
  quality_flags = S.quality_flags,
  source = S.source,
  updated_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT (
  base_datetime, ingested_at, source_timezone, demand_mw,
  is_corrected, quality_flags, source, updated_at
) VALUES (
  S.base_datetime, S.ingested_at, S.source_timezone, S.demand_mw,
  S.is_corrected, S.quality_flags, S.source, CURRENT_TIMESTAMP()
);
