-- 목적: 5분 또는 약간 어긋난 시각의 row를 가장 가까운 15분 grid로 정렬한다.

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_15m_v` AS
WITH bucketed AS (
  SELECT
    TIMESTAMP_SECONDS(900 * DIV(UNIX_SECONDS(base_datetime) + 450, 900)) AS base_datetime_15m,
    base_datetime AS source_base_datetime,
    ingested_at,
    source_timezone,
    demand_mw,
    is_corrected,
    quality_flags,
    source,
    ABS(
      TIMESTAMP_DIFF(
        base_datetime,
        TIMESTAMP_SECONDS(900 * DIV(UNIX_SECONDS(base_datetime) + 450, 900)),
        SECOND
      )
    ) AS diff_sec
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_5m`
), ranked AS (
  SELECT
    *,
    ROW_NUMBER() OVER (
      PARTITION BY base_datetime_15m
      ORDER BY diff_sec ASC, ingested_at DESC, source_base_datetime DESC
    ) AS rn
  FROM bucketed
)
SELECT
  base_datetime_15m AS base_datetime,
  source_base_datetime,
  ingested_at,
  source_timezone,
  demand_mw,
  is_corrected,
  quality_flags,
  source
FROM ranked
WHERE rn = 1;

-- 검증 예시
-- SELECT COUNT(*) AS row_count,
--        COUNTIF(MOD(EXTRACT(MINUTE FROM base_datetime), 15) = 0) AS on_grid_count,
--        MIN(base_datetime) AS min_dt,
--        MAX(base_datetime) AS max_dt
-- FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.silver_demand_15m_v`;
