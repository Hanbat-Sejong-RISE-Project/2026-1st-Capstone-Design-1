-- 목적: 운영 raw는 읽기 전용 원천으로 두고, silver 이후 계층만 review dataset에 만든다.
-- 사용 전 {{PROJECT_ID}}, {{RAW_DATASET_ID}}, {{REVIEW_DATASET_ID}}, {{LOCATION}} 값을 실제 환경에 맞게 치환한다.

CREATE SCHEMA IF NOT EXISTS `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}`
OPTIONS(location = '{{LOCATION}}');

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_raw_kpx_5m_shared` AS
SELECT
  base_datetime,
  ingested_at,
  source_timezone,
  SAFE_CAST(demand_mw AS FLOAT64) AS demand_mw,
  source,
  ingestion_id,
  payload_json
FROM `{{PROJECT_ID}}.{{RAW_DATASET_ID}}.raw_kpx_5m`;

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_review_anchor_time` AS
SELECT
  MAX(base_datetime) AS anchor_base_datetime,
  TIMESTAMP_TRUNC(MAX(base_datetime), HOUR) AS anchor_hour
FROM `{{PROJECT_ID}}.{{RAW_DATASET_ID}}.raw_kpx_5m`;
