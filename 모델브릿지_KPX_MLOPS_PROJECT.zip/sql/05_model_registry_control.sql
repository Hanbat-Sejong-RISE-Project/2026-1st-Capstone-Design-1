-- 목적: predictions, run log, model registry control을 review dataset에 만든다.

CREATE TABLE IF NOT EXISTS `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.predictions` (
  prediction_time TIMESTAMP NOT NULL,
  horizon_min INT64 NOT NULL,
  target_time TIMESTAMP NOT NULL,
  cutoff_time TIMESTAMP,
  yhat FLOAT64,
  model_version STRING NOT NULL,
  prediction_method STRING,
  gate_status STRING,
  gate_reason STRING,
  feature_version STRING,
  predicted_at TIMESTAMP,
  data_freshness_min INT64,
  pipeline_run_id STRING,
  created_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.prediction_run_log` (
  pipeline_run_id STRING NOT NULL,
  run_type STRING,
  model_version STRING,
  status STRING,
  gate_status STRING,
  error_message STRING,
  prediction_count INT64,
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  created_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.model_registry_control` (
  model_version STRING NOT NULL,
  model_type STRING,
  artifact_uri STRING,
  vertex_model_resource_name STRING,
  status STRING,
  is_current BOOL,
  feature_version STRING,
  valid_wmape FLOAT64,
  test_wmape FLOAT64,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

CREATE OR REPLACE VIEW `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.v_current_model_control` AS
WITH current_rows AS (
  SELECT *
  FROM `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.model_registry_control`
  WHERE is_current = TRUE
), current_count AS (
  SELECT COUNT(*) AS cnt
  FROM current_rows
)
SELECT c.*
FROM current_rows AS c
CROSS JOIN current_count AS cc
WHERE cc.cnt = 1
QUALIFY ROW_NUMBER() OVER (ORDER BY updated_at DESC) = 1;

-- current 전환 예시는 검증 후에만 실행한다.
-- BEGIN TRANSACTION;
-- UPDATE `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.model_registry_control`
-- SET is_current = FALSE, updated_at = CURRENT_TIMESTAMP()
-- WHERE is_current = TRUE;
-- UPDATE `{{PROJECT_ID}}.{{REVIEW_DATASET_ID}}.model_registry_control`
-- SET is_current = TRUE, status = 'ACTIVE', updated_at = CURRENT_TIMESTAMP()
-- WHERE model_version = '{{MODEL_VERSION}}';
-- COMMIT TRANSACTION;
