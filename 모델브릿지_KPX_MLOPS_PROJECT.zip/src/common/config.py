from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    project_id: str
    region: str
    raw_dataset_id: str
    raw_table_id: str
    dataset_id: str
    input_view: str
    model_control_view: str
    predictions_table: str
    run_log_table: str
    prediction_method: str
    pipeline_run_id: str | None = None
    model_version_override: str | None = None

    @property
    def input_view_fqn(self) -> str:
        return f"{self.project_id}.{self.dataset_id}.{self.input_view}"

    @property
    def model_control_view_fqn(self) -> str:
        return f"{self.project_id}.{self.dataset_id}.{self.model_control_view}"

    @property
    def predictions_table_fqn(self) -> str:
        return f"{self.project_id}.{self.dataset_id}.{self.predictions_table}"

    @property
    def run_log_table_fqn(self) -> str:
        return f"{self.project_id}.{self.dataset_id}.{self.run_log_table}"


def load_settings() -> Settings:
    """Cloud Run Job 환경변수에서 실행 설정을 읽는다."""
    return Settings(
        project_id=os.environ["PROJECT_ID"],
        region=os.environ.get("REGION", "asia-northeast3"),
        raw_dataset_id=os.environ.get("RAW_DATASET_ID", "kpx_power"),
        raw_table_id=os.environ.get("RAW_TABLE_ID", "raw_kpx_5m"),
        dataset_id=os.environ.get("DATASET_ID", "kpx_power_review"),
        input_view=os.environ.get("INPUT_VIEW", "silver_demand_15m_v"),
        model_control_view=os.environ.get("MODEL_CONTROL_VIEW", "v_current_model_control"),
        predictions_table=os.environ.get("PREDICTIONS_TABLE", "predictions"),
        run_log_table=os.environ.get("RUN_LOG_TABLE", "prediction_run_log"),
        prediction_method=os.environ.get("PREDICTION_METHOD", "transformer_direct_24step"),
        pipeline_run_id=os.environ.get("PIPELINE_RUN_ID") or None,
        model_version_override=os.environ.get("MODEL_VERSION") or None,
    )
