from __future__ import annotations

import json
import shutil
from pathlib import Path
from urllib.parse import urlparse

from google.cloud import storage


def parse_gs_uri(uri: str) -> tuple[str, str]:
    if not uri.startswith("gs://"):
        raise ValueError(f"GCS URI가 아닙니다: {uri}")
    parsed = urlparse(uri)
    bucket = parsed.netloc
    prefix = parsed.path.lstrip("/")
    return bucket, prefix.rstrip("/")


def download_gcs_prefix(uri: str, local_dir: Path) -> Path:
    bucket_name, prefix = parse_gs_uri(uri)
    local_dir.mkdir(parents=True, exist_ok=True)
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blobs = list(client.list_blobs(bucket_name, prefix=prefix))
    if not blobs:
        raise FileNotFoundError(f"artifact prefix가 비어 있습니다: {uri}")
    for blob in blobs:
        rel = blob.name[len(prefix):].lstrip("/")
        if not rel:
            continue
        dst = local_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        blob.download_to_filename(dst)
    return local_dir


def load_json(path: Path) -> dict | list:
    return json.loads(path.read_text(encoding="utf-8"))


def assert_manifest(local_dir: Path) -> dict:
    manifest_path = local_dir / "artifact_manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError("artifact_manifest.json이 없습니다.")
    manifest = load_json(manifest_path)
    missing = [name for name in manifest.get("required_files", []) if not (local_dir / name).exists()]
    if missing:
        raise FileNotFoundError(f"필수 artifact가 없습니다: {missing}")
    return manifest


def prepare_local_artifacts(artifact_uri: str, work_dir: Path) -> Path:
    if work_dir.exists():
        shutil.rmtree(work_dir)
    return download_gcs_prefix(artifact_uri, work_dir)
