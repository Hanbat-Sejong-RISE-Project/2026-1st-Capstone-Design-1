from __future__ import annotations

import numpy as np
import pandas as pd

BASELINE_FEATURE_COLUMNS = [
    "demand_mw",
    "target_lag_1", "target_lag_4", "target_lag_96",
    "target_roll_mean_4", "target_roll_mean_12", "target_roll_std_12",
    "target_roll_mean_96", "target_roll_std_96",
    "target_ramp_1", "target_ramp_4",
    "hour", "dayofweek", "month", "slot_15m",
    "is_weekend",
    "hour_sin", "hour_cos",
    "dayofweek_sin", "dayofweek_cos",
    "quarter_slot_sin", "quarter_slot_cos",
]


def add_time_and_history_features(df: pd.DataFrame) -> pd.DataFrame:
    """BigQuery training feature SQL과 같은 계약의 feature를 pandas에서도 만든다."""
    out = df.copy()
    out["base_datetime"] = pd.to_datetime(out["base_datetime"], utc=True)
    out = out.sort_values("base_datetime").reset_index(drop=True)
    y = out["demand_mw"].astype(float)

    out["target_lag_1"] = y.shift(1)
    out["target_lag_4"] = y.shift(4)
    out["target_lag_96"] = y.shift(96)
    out["target_roll_mean_4"] = y.shift(1).rolling(4).mean()
    out["target_roll_mean_12"] = y.shift(1).rolling(12).mean()
    out["target_roll_std_12"] = y.shift(1).rolling(12).std()
    out["target_roll_mean_96"] = y.shift(1).rolling(96).mean()
    out["target_roll_std_96"] = y.shift(1).rolling(96).std()
    out["target_ramp_1"] = y - y.shift(1)
    out["target_ramp_4"] = y - y.shift(4)

    dt = out["base_datetime"]
    out["hour"] = dt.dt.hour.astype(float)
    out["dayofweek"] = dt.dt.dayofweek.astype(float)  # Monday=0, Sunday=6
    out["month"] = dt.dt.month.astype(float)
    out["slot_15m"] = (dt.dt.hour * 4 + (dt.dt.minute // 15)).astype(float)
    out["is_weekend"] = (out["dayofweek"] >= 5).astype(float)

    out["hour_sin"] = np.sin(2 * np.pi * out["hour"] / 24)
    out["hour_cos"] = np.cos(2 * np.pi * out["hour"] / 24)
    out["dayofweek_sin"] = np.sin(2 * np.pi * out["dayofweek"] / 7)
    out["dayofweek_cos"] = np.cos(2 * np.pi * out["dayofweek"] / 7)
    out["quarter_slot_sin"] = np.sin(2 * np.pi * out["slot_15m"] / 96)
    out["quarter_slot_cos"] = np.cos(2 * np.pi * out["slot_15m"] / 96)
    return out


def make_training_windows(
    feature_df: pd.DataFrame,
    feature_columns: list[str],
    input_window: int = 96,
    horizon: int = 24,
) -> tuple[np.ndarray, np.ndarray, list[pd.Timestamp]]:
    """정렬된 feature_df에서 direct multi-step 학습 window를 만든다."""
    clean = feature_df.dropna(subset=feature_columns + ["demand_mw"]).copy()
    clean = clean.sort_values("base_datetime").reset_index(drop=True)
    features = clean[feature_columns].astype(float).to_numpy()
    target = clean["demand_mw"].astype(float).to_numpy()
    times = pd.to_datetime(clean["base_datetime"], utc=True).to_list()

    x_list, y_list, t_list = [], [], []
    for end_idx in range(input_window - 1, len(clean) - horizon):
        start_idx = end_idx - input_window + 1
        x_list.append(features[start_idx : end_idx + 1])
        y_list.append(target[end_idx + 1 : end_idx + 1 + horizon])
        t_list.append(times[end_idx])

    return np.asarray(x_list, dtype=np.float32), np.asarray(y_list, dtype=np.float32), t_list


def build_latest_input(
    raw_df: pd.DataFrame,
    feature_columns: list[str],
    input_window: int,
) -> tuple[np.ndarray, pd.Timestamp]:
    """Cloud Run inference에서 최근 lookback row를 받아 마지막 input_window만 모델 입력으로 만든다."""
    featured = add_time_and_history_features(raw_df)
    clean = featured.dropna(subset=feature_columns).copy()
    if len(clean) < input_window:
        raise ValueError(f"not enough valid rows: {len(clean)} < {input_window}")
    recent = clean.tail(input_window)
    x = recent[feature_columns].astype(float).to_numpy(dtype=np.float32)
    prediction_time = pd.to_datetime(recent["base_datetime"].iloc[-1], utc=True)
    return x[None, :, :], prediction_time
