from __future__ import annotations

import math
import torch
from torch import nn


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 512, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, d_model)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.pe[:, : x.size(1)]
        return self.dropout(x)


class TransformerDirectForecaster(nn.Module):
    """최근 input_window 시퀀스에서 horizon개 미래 값을 한 번에 출력하는 모델."""

    def __init__(
        self,
        feature_count: int,
        horizon: int = 24,
        d_model: int = 64,
        nhead: int = 4,
        num_layers: int = 2,
        dim_feedforward: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.feature_count = feature_count
        self.horizon = horizon
        self.input_projection = nn.Linear(feature_count, d_model)
        self.positional_encoding = PositionalEncoding(d_model=d_model, dropout=dropout)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, horizon),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [batch, input_window, feature_count]
        z = self.input_projection(x)
        z = self.positional_encoding(z)
        z = self.encoder(z)
        last_state = z[:, -1, :]
        return self.head(last_state)


def build_model_from_config(config: dict) -> TransformerDirectForecaster:
    return TransformerDirectForecaster(
        feature_count=int(config["feature_count"]),
        horizon=int(config.get("horizon", 24)),
        d_model=int(config.get("d_model", 64)),
        nhead=int(config.get("nhead", config.get("num_heads", 4))),
        num_layers=int(config.get("num_layers", 2)),
        dim_feedforward=int(config.get("dim_feedforward", 128)),
        dropout=float(config.get("dropout", 0.1)),
    )
