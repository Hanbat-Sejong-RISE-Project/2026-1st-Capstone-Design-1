from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from google.cloud import bigquery

from src.common.artifacts import assert_manifest, load_json, prepare_local_artifacts
from src.common.config import Settings, load_settings
from src.common.features import build_latest_input
from src.common.model import build_model_from_config

CODE_VERSION = "portfolio-sequence-inference-v1"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def get_pipeline_run_id(settings: Settings) -> str:
    return settings.pipeline_run_id or f"cloud-run-{uuid.uuid4().hex[:16]}"


def query_current_model(client: bigquery.Client, settings: Settings) -> dict:
    if settings.model_version_override:
        query = f"""
        SELECT *
        FROM `{settings.project_id}.{settings.dataset_id}.model_registry_control`
        WHERE model_version = @model_version
        LIMIT 1
        """
        job_config = bigquery.QueryJobConfig(
            query_parameters=[bigquery.ScalarQueryParameter("model_version", "STRING", settings.model_version_override)]
        )
    else:
        query = f"SELECT * FROM `{settings.model_control_view_fqn}` LIMIT 1"
        job_config = None

    rows = list(client.query(query, job_config=job_config).result())
    if len(rows) != 1:
        raise RuntimeError("current model이 정확히 1개가 아닙니다. 추론을 중단합니다.")
    return dict(rows[0].items())


def query_recent_rows(client: bigquery.Client, settings: Settings, input_window: int) -> pd.DataFrame:
    # lag_96 / rolling_96 계산 때문에 input_window보다 넉넉하게 가져온다.
    read_rows = input_window + 160
    query = f"""
    SELECT base_datetime, demand_mw
    FROM `{settings.input_view_fqn}`
    WHERE demand_mw IS NOT NULL
    ORDER BY base_datetime DESC
    LIMIT @read_rows
    """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[bigquery.ScalarQueryParameter("read_rows", "INT64", read_rows)]
    )
    df = client.query(query, job_config=job_config).to_dataframe()
    return df.sort_values("base_datetime").reset_index(drop=True)


def apply_json_scaler(x: np.ndarray, scaler: dict | None) -> np.ndarray:
    if not scaler:
        return x
    mean = np.asarray(scaler["mean"], dtype=np.float32)
    scale = np.asarray(scaler["scale"], dtype=np.float32)
    scale = np.where(scale == 0, 1.0, scale)
    return (x - mean) / scale


def inverse_target(y: np.ndarray, scaler: dict | None) -> np.ndarray:
    if not scaler:
        return y
    mean = float(np.asarray(scaler["mean"]).reshape(-1)[0])
    scale = float(np.asarray(scaler["scale"]).reshape(-1)[0]) or 1.0
    return y * scale + mean


def load_model(local_dir: Path, device: str):
    model_config = load_json(local_dir / "model_config.json")
    model = build_model_from_config(model_config).to(device)
    checkpoint = torch.load(local_dir / "model.pt", map_location=device)
    state_dict = checkpoint.get("state_dict", checkpoint)
    model.load_state_dict(state_dict)
    model.eval()
    return model, model_config


def prediction_dataframe(
    prediction_time: pd.Timestamp,
    yhat: np.ndarray,
    model_row: dict,
    settings: Settings,
    pipeline_run_id: str,
) -> pd.DataFrame:
    yhat = np.asarray(yhat, dtype=float).reshape(-1)
    now = utc_now()
    rows = []
    for idx, value in enumerate(yhat, start=1):
        horizon_min = idx * 15
        rows.append({
            "prediction_time": prediction_time.to_pydatetime(),
            "horizon_min": horizon_min,
            "target_time": (prediction_time + pd.Timedelta(minutes=horizon_min)).to_pydatetime(),
            "cutoff_time": prediction_time.to_pydatetime(),
            "yhat": float(value),
            "model_version": model_row["model_version"],
            "prediction_method": settings.prediction_method,
            "gate_status": "passed",
            "gate_reason": None,
            "feature_version": model_row.get("feature_version"),
            "predicted_at": now,
            "data_freshness_min": 0,
            "pipeline_run_id": pipeline_run_id,
            "created_at": now,
        })
    return pd.DataFrame(rows)


def merge_predictions(client: bigquery.Client, settings: Settings, df: pd.DataFrame, pipeline_run_id: str):
    staging = f"{settings.project_id}.{settings.dataset_id}._staging_predictions_{pipeline_run_id.replace('-', '_')}"
    job = client.load_table_from_dataframe(df, staging)
    job.result()
    merge_sql = f"""
    MERGE `{settings.predictions_table_fqn}` T
    USING `{staging}` S
    ON T.prediction_time = S.prediction_time
       AND T.horizon_min = S.horizon_min
       AND T.model_version = S.model_version
    WHEN MATCHED THEN UPDATE SET
      target_time = S.target_time,
      cutoff_time = S.cutoff_time,
      yhat = S.yhat,
      prediction_method = S.prediction_method,
      gate_status = S.gate_status,
      gate_reason = S.gate_reason,
      feature_version = S.feature_version,
      predicted_at = S.predicted_at,
      data_freshness_min = S.data_freshness_min,
      pipeline_run_id = S.pipeline_run_id,
      created_at = S.created_at
    WHEN NOT MATCHED THEN INSERT (
      prediction_time, horizon_min, target_time, cutoff_time, yhat,
      model_version, prediction_method, gate_status, gate_reason, feature_version,
      predicted_at, data_freshness_min, pipeline_run_id, created_at
    ) VALUES (
      S.prediction_time, S.horizon_min, S.target_time, S.cutoff_time, S.yhat,
      S.model_version, S.prediction_method, S.gate_status, S.gate_reason, S.feature_version,
      S.predicted_at, S.data_freshness_min, S.pipeline_run_id, S.created_at
    )
    """
    client.query(merge_sql).result()
    client.delete_table(staging, not_found_ok=True)


def merge_run_log(
    client: bigquery.Client,
    settings: Settings,
    pipeline_run_id: str,
    run_type: str,
    model_version: str | None,
    status: str,
    gate_status: str,
    error_message: str | None,
    prediction_count: int,
    started_at: datetime,
    ended_at: datetime,
):
    query = f"""
    MERGE `{settings.run_log_table_fqn}` T
    USING (
      SELECT
        @pipeline_run_id AS pipeline_run_id,
        @run_type AS run_type,
        @model_version AS model_version,
        @status AS status,
        @gate_status AS gate_status,
        @error_message AS error_message,
        @prediction_count AS prediction_count,
        @started_at AS started_at,
        @ended_at AS ended_at,
        @created_at AS created_at
    ) S
    ON T.pipeline_run_id = S.pipeline_run_id
    WHEN MATCHED THEN UPDATE SET
      run_type = S.run_type,
      model_version = S.model_version,
      status = S.status,
      gate_status = S.gate_status,
      error_message = S.error_message,
      prediction_count = S.prediction_count,
      started_at = S.started_at,
      ended_at = S.ended_at,
      created_at = S.created_at
    WHEN NOT MATCHED THEN INSERT (
      pipeline_run_id, run_type, model_version, status, gate_status,
      error_message, prediction_count, started_at, ended_at, created_at
    ) VALUES (
      S.pipeline_run_id, S.run_type, S.model_version, S.status, S.gate_status,
      S.error_message, S.prediction_count, S.started_at, S.ended_at, S.created_at
    )
    """
    params = [
        bigquery.ScalarQueryParameter("pipeline_run_id", "STRING", pipeline_run_id),
        bigquery.ScalarQueryParameter("run_type", "STRING", run_type),
        bigquery.ScalarQueryParameter("model_version", "STRING", model_version),
        bigquery.ScalarQueryParameter("status", "STRING", status),
        bigquery.ScalarQueryParameter("gate_status", "STRING", gate_status),
        bigquery.ScalarQueryParameter("error_message", "STRING", error_message),
        bigquery.ScalarQueryParameter("prediction_count", "INT64", prediction_count),
        bigquery.ScalarQueryParameter("started_at", "TIMESTAMP", started_at),
        bigquery.ScalarQueryParameter("ended_at", "TIMESTAMP", ended_at),
        bigquery.ScalarQueryParameter("created_at", "TIMESTAMP", ended_at),
    ]
    client.query(query, job_config=bigquery.QueryJobConfig(query_parameters=params)).result()


def main():
    settings = load_settings()
    client = bigquery.Client(project=settings.project_id)
    pipeline_run_id = get_pipeline_run_id(settings)
    started_at = utc_now()
    model_version = None

    print(f"CODE_VERSION={CODE_VERSION}", flush=True)
    print(f"PROJECT_ID={settings.project_id}", flush=True)
    print(f"DATASET_ID={settings.dataset_id}", flush=True)
    print(f"INPUT_VIEW={settings.input_view}", flush=True)
    print(f"MODEL_CONTROL_VIEW={settings.model_control_view}", flush=True)

    try:
        model_row = query_current_model(client, settings)
        model_version = model_row["model_version"]
        artifact_uri = model_row["artifact_uri"]
        print(f"MODEL_VERSION={model_version}", flush=True)
        print(f"ARTIFACT_URI={artifact_uri}", flush=True)

        with tempfile.TemporaryDirectory() as tmp:
            local_dir = prepare_local_artifacts(artifact_uri, Path(tmp) / "model")
            manifest = assert_manifest(local_dir)
            feature_columns = load_json(local_dir / "feature_columns.json")
            feature_scaler = load_json(local_dir / "feature_scaler.json") if (local_dir / "feature_scaler.json").exists() else None
            target_scaler = load_json(local_dir / "target_scaler.json") if (local_dir / "target_scaler.json").exists() else None
            input_window = int(manifest.get("input_window", 96))
            horizon = int(manifest.get("horizon", 24))

            recent_df = query_recent_rows(client, settings, input_window=input_window)
            x, prediction_time = build_latest_input(recent_df, feature_columns, input_window)
            x = apply_json_scaler(x, feature_scaler)

            device = "cuda" if torch.cuda.is_available() else "cpu"
            model, _ = load_model(local_dir, device)
            with torch.no_grad():
                yhat = model(torch.tensor(x, dtype=torch.float32).to(device)).cpu().numpy().reshape(-1)
            yhat = inverse_target(yhat, target_scaler)

            if len(yhat) != horizon:
                raise RuntimeError(f"예측 결과 개수가 horizon과 다릅니다: {len(yhat)} != {horizon}")
            if not np.isfinite(yhat).all():
                raise RuntimeError("예측값에 NaN 또는 Inf가 있습니다.")

            pred_df = prediction_dataframe(prediction_time, yhat, model_row, settings, pipeline_run_id)
            merge_predictions(client, settings, pred_df, pipeline_run_id)

        ended_at = utc_now()
        merge_run_log(client, settings, pipeline_run_id, "inference", model_version, "success", "passed", None, len(yhat), started_at, ended_at)
        print(f"prediction_count={len(yhat)}", flush=True)
    except Exception as exc:
        ended_at = utc_now()
        merge_run_log(client, settings, pipeline_run_id, "inference", model_version, "failed", "failed", str(exc), 0, started_at, ended_at)
        print(f"ERROR={exc}", flush=True)
        raise


if __name__ == "__main__":
    main()
