from __future__ import annotations

import argparse
from pathlib import Path

from google.cloud import bigquery


def render_sql(template: str, values: dict[str, str]) -> str:
    sql = template
    for key, value in values.items():
        sql = sql.replace("{{" + key + "}}", value)
    return sql


def main():
    parser = argparse.ArgumentParser(description="BigQuery SQL template 실행 도구")
    parser.add_argument("sql_file", help="실행할 SQL 파일 경로")
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--raw-dataset-id", default="kpx_power")
    parser.add_argument("--review-dataset-id", default="kpx_power_review")
    parser.add_argument("--location", default="asia-northeast3")
    parser.add_argument("--model-version", default="transformer_demand_24step_review_v1")
    args = parser.parse_args()

    values = {
        "PROJECT_ID": args.project_id,
        "RAW_DATASET_ID": args.raw_dataset_id,
        "REVIEW_DATASET_ID": args.review_dataset_id,
        "LOCATION": args.location,
        "MODEL_VERSION": args.model_version,
    }
    template = Path(args.sql_file).read_text(encoding="utf-8")
    sql = render_sql(template, values)
    client = bigquery.Client(project=args.project_id)
    job = client.query(sql)
    job.result()
    print(f"done: {args.sql_file}")


if __name__ == "__main__":
    main()
