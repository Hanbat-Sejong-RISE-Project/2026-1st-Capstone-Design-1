from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from google.cloud import bigquery, storage
from sklearn.preprocessing import StandardScaler
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from src.common.features import BASELINE_FEATURE_COLUMNS, add_time_and_history_features, make_training_windows
from src.common.metrics import mae, rmse, wmape, mape
from src.common.model import TransformerDirectForecaster


def read_training_source(project_id: str, dataset_id: str, table_id: str) -> pd.DataFrame:
    client = bigquery.Client(project=project_id)
    query = f"""
    SELECT base_datetime, demand_mw
    FROM `{project_id}.{dataset_id}.{table_id}`
    WHERE demand_mw IS NOT NULL
    ORDER BY base_datetime
    """
    return client.query(query).to_dataframe()


def split_by_time(x, y, times):
    times = pd.to_datetime(times, utc=True)
    max_time = times.max()
    valid_cutoff = max_time - pd.Timedelta(days=30)
    test_cutoff = max_time - pd.Timedelta(days=14)

    train_idx = times < valid_cutoff
    valid_idx = (times >= valid_cutoff) & (times < test_cutoff)
    test_idx = times >= test_cutoff
    return (x[train_idx], y[train_idx]), (x[valid_idx], y[valid_idx]), (x[test_idx], y[test_idx])


def fit_transform_scalers(x_train, y_train, x_valid, y_valid, x_test, y_test):
    feature_scaler = StandardScaler()
    target_scaler = StandardScaler()

    n_features = x_train.shape[-1]
    feature_scaler.fit(x_train.reshape(-1, n_features))
    target_scaler.fit(y_train.reshape(-1, 1))

    def sx(x):
        return feature_scaler.transform(x.reshape(-1, n_features)).reshape(x.shape).astype(np.float32)

    def sy(y):
        return target_scaler.transform(y.reshape(-1, 1)).reshape(y.shape).astype(np.float32)

    return sx(x_train), sy(y_train), sx(x_valid), sy(y_valid), sx(x_test), sy(y_test), feature_scaler, target_scaler


def train_epoch(model, loader, optimizer, loss_fn, device):
    model.train()
    total = 0.0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        optimizer.zero_grad()
        pred = model(xb)
        loss = loss_fn(pred, yb)
        loss.backward()
        optimizer.step()
        total += loss.item() * len(xb)
    return total / len(loader.dataset)


@torch.no_grad()
def predict_scaled(model, x, device, batch_size=256):
    model.eval()
    preds = []
    loader = DataLoader(TensorDataset(torch.tensor(x, dtype=torch.float32)), batch_size=batch_size)
    for (xb,) in loader:
        preds.append(model(xb.to(device)).cpu().numpy())
    return np.vstack(preds)


def save_json(path: Path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def upload_dir(local_dir: Path, artifact_uri: str):
    if not artifact_uri.startswith("gs://"):
        return
    uri = artifact_uri.removeprefix("gs://")
    bucket_name, prefix = uri.split("/", 1)
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    for file in local_dir.rglob("*"):
        if file.is_file():
            blob = bucket.blob(f"{prefix.rstrip('/')}/{file.relative_to(local_dir).as_posix()}")
            blob.upload_from_filename(file)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--dataset-id", default="kpx_power_review")
    parser.add_argument("--source-table", default="silver_demand_15m_v")
    parser.add_argument("--model-version", required=True)
    parser.add_argument("--artifact-uri", required=True)
    parser.add_argument("--output-dir", default="outputs/model")
    parser.add_argument("--input-window", type=int, default=96)
    parser.add_argument("--horizon", type=int, default=24)
    parser.add_argument("--max-epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--lr", type=float, default=1e-3)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    df = read_training_source(args.project_id, args.dataset_id, args.source_table)
    feature_df = add_time_and_history_features(df)
    x, y, times = make_training_windows(feature_df, BASELINE_FEATURE_COLUMNS, args.input_window, args.horizon)
    (x_train, y_train), (x_valid, y_valid), (x_test, y_test) = split_by_time(x, y, times)

    x_train_s, y_train_s, x_valid_s, y_valid_s, x_test_s, y_test_s, feature_scaler, target_scaler = fit_transform_scalers(
        x_train, y_train, x_valid, y_valid, x_test, y_test
    )

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model_config = {
        "model_type": "TransformerDirectForecaster",
        "input_window": args.input_window,
        "horizon": args.horizon,
        "feature_count": len(BASELINE_FEATURE_COLUMNS),
        "d_model": 64,
        "nhead": 4,
        "num_layers": 2,
        "dim_feedforward": 128,
        "dropout": 0.1,
    }
    model = TransformerDirectForecaster(**{k: v for k, v in model_config.items() if k != "model_type"}).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = nn.MSELoss()
    loader = DataLoader(
        TensorDataset(torch.tensor(x_train_s, dtype=torch.float32), torch.tensor(y_train_s, dtype=torch.float32)),
        batch_size=args.batch_size,
        shuffle=True,
    )

    best_valid = float("inf")
    best_state = None
    patience = 5
    wait = 0
    for epoch in range(1, args.max_epochs + 1):
        train_loss = train_epoch(model, loader, optimizer, loss_fn, device)
        valid_pred_s = predict_scaled(model, x_valid_s, device)
        valid_loss = float(np.mean((valid_pred_s - y_valid_s) ** 2))
        print(f"epoch={epoch} train_loss={train_loss:.6f} valid_loss={valid_loss:.6f}", flush=True)
        if valid_loss < best_valid:
            best_valid = valid_loss
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                break

    model.load_state_dict(best_state)
    valid_pred = target_scaler.inverse_transform(predict_scaled(model, x_valid_s, device).reshape(-1, 1)).reshape(y_valid.shape)
    test_pred = target_scaler.inverse_transform(predict_scaled(model, x_test_s, device).reshape(-1, 1)).reshape(y_test.shape)

    metrics = {
        "train_sample_count": int(len(x_train)),
        "valid_sample_count": int(len(x_valid)),
        "test_sample_count": int(len(x_test)),
        "valid_wmape": wmape(y_valid.reshape(-1), valid_pred.reshape(-1)),
        "test_wmape": wmape(y_test.reshape(-1), test_pred.reshape(-1)),
        "valid_mape": mape(y_valid.reshape(-1), valid_pred.reshape(-1)),
        "test_mape": mape(y_test.reshape(-1), test_pred.reshape(-1)),
        "valid_mae": mae(y_valid.reshape(-1), valid_pred.reshape(-1)),
        "test_mae": mae(y_test.reshape(-1), test_pred.reshape(-1)),
        "test_rmse": rmse(y_test.reshape(-1), test_pred.reshape(-1)),
        "input_window": args.input_window,
        "horizon": args.horizon,
        "max_epochs": args.max_epochs,
    }

    torch.save({"state_dict": model.state_dict(), "model_config": model_config, "feature_columns": BASELINE_FEATURE_COLUMNS}, output_dir / "model.pt")
    save_json(output_dir / "feature_columns.json", BASELINE_FEATURE_COLUMNS)
    save_json(output_dir / "model_config.json", model_config)
    save_json(output_dir / "preprocessing_config.json", {"freq": "15min", "missing_policy": "drop_lag_rolling_nulls"})
    save_json(output_dir / "metrics.json", metrics)
    save_json(output_dir / "feature_scaler.json", {"mean": feature_scaler.mean_.tolist(), "scale": feature_scaler.scale_.tolist()})
    save_json(output_dir / "target_scaler.json", {"mean": target_scaler.mean_.tolist(), "scale": target_scaler.scale_.tolist()})
    save_json(output_dir / "artifact_manifest.json", {
        "model_version": args.model_version,
        "model_type": "TransformerDirectForecaster",
        "feature_version": "transformer_seq_baseline_v2",
        "required_files": ["model.pt", "feature_columns.json", "model_config.json", "preprocessing_config.json", "metrics.json"],
        "optional_files": ["feature_scaler.json", "target_scaler.json"],
        "input_window": args.input_window,
        "horizon": args.horizon,
    })
    upload_dir(output_dir, args.artifact_uri)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
