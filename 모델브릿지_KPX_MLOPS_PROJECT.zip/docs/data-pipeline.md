# Data Pipeline

데이터 파이프라인은 raw, silver, 15분 view로 나누었다.

- raw: KPX 5분 단위 원천 데이터
- silver: 같은 base_datetime 중 최신 ingested_at 1건만 유지
- 15분 view: 가장 가까운 15분 grid로 정렬한 모델 입력 view

BigQuery SQL은 `sql/01_create_review_dataset.sql`부터 순서대로 실행하면 된다. 실제 프로젝트 ID와 dataset 이름은 SQL 파일의 placeholder를 치환해서 사용한다.

주의할 점은 review dataset 안에 raw copy를 만들지 않는 것이다. raw copy가 생기면 어느 데이터가 기준인지 헷갈리고, 운영 데이터와 실험 데이터가 어긋날 수 있다.
