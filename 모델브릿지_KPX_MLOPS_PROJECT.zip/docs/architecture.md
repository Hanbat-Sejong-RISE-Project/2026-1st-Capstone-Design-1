# Architecture

이 프로젝트는 원천 데이터를 직접 고치지 않고, raw 이후 계층을 review dataset에 분리해서 운영 흐름을 검증하는 구조로 잡았다.

흐름은 다음과 같다.

    kpx_power.raw_kpx_5m
      -> kpx_power_review.silver_demand_5m
      -> kpx_power_review.silver_demand_15m_v
      -> train_sequence_15m_base_v1
      -> Vertex AI Pipelines
      -> GCS model artifacts
      -> model_registry_control
      -> Cloud Run Job inference
      -> predictions / prediction_run_log
      -> delayed evaluation
      -> Looker Studio views

핵심 원칙은 세 가지다.

1. raw는 읽기 전용으로만 사용한다.
2. current 모델은 항상 정확히 1개일 때만 추론한다.
3. 학습과 추론의 feature 순서는 `feature_columns.json`으로 맞춘다.
