# MLOps Pipeline

학습이 끝난 모델은 곧바로 current로 올리지 않는다. 먼저 CANDIDATE로 등록하고, artifact와 metric을 확인한 뒤 current 전환을 한다.

필수 artifact는 다음과 같다.

- model.pt
- feature_columns.json
- model_config.json
- preprocessing_config.json
- metrics.json
- artifact_manifest.json

Cloud Run inference는 시작할 때 `artifact_manifest.json`을 먼저 확인한다. 필수 파일이 누락되면 predictions에 쓰지 않고 run log에 실패를 남긴다.

current 전환은 transaction으로 처리하고, `v_current_model_control`은 current가 정확히 1개일 때만 row를 반환한다.
