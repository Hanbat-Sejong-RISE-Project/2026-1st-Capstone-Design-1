# Troubleshooting

## predictions가 24개 쌓이지 않을 때

- current_count가 1인지 확인한다.
- artifact_manifest.json과 필수 파일이 있는지 확인한다.
- Cloud Run image가 현재 feature_columns.json의 feature 개수와 맞는지 확인한다.
- 최근 input row가 input_window 이상인지 확인한다.

## 같은 prediction_time만 반복될 때

raw는 최신인데 review silver가 멈춰 있을 수 있다. `02_raw_to_silver_merge.sql`을 다시 실행하거나 Scheduled Query 상태를 확인한다.

## Looker에서 WMAPE/MAPE가 이상하게 크게 보일 때

BigQuery에서 이미 계산된 run-level 지표를 Looker에서 SUM으로 다시 집계하면 값이 왜곡된다. AVG 또는 단일 row KPI view를 사용한다.

## Cloud Scheduler를 켰는데 실행이 겹칠 때

검증 단계에서는 Scheduler를 계속 켜 두지 않는다. `resume -> run now -> pause` 순서로 짧게 검증한다.
