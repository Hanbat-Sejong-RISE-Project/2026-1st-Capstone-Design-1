# Model Experiments

모델은 단순 기준선부터 시작했다.

- Last-value baseline: 수집, 정제, 예측, 평가 루프 검증용
- LightGBM: 트리 기반 비교군
- LSTM / GRU / TCN: 시계열 딥러닝 비교군
- Transformer: 운영 파이프라인 우선 후보
- N-HiTS: 후속 성능 개선 후보

오프라인 실험 결과는 README에 요약했고, 이 저장소의 코드는 Transformer direct 24-step 모델을 중심으로 구성했다. N-HiTS는 입력 계약과 실험 방향을 남겨두되, 실제 실행 코드는 후속 확장 항목으로 분리하는 것이 안전하다.
