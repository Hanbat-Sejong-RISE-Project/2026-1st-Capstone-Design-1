#!/usr/bin/env bash
set -euo pipefail

SQL_FILE="${1:?SQL file path required}"
PROJECT_ID="${PROJECT_ID:?PROJECT_ID env required}"
RAW_DATASET_ID="${RAW_DATASET_ID:-kpx_power}"
REVIEW_DATASET_ID="${REVIEW_DATASET_ID:-kpx_power_review}"
LOCATION="${LOCATION:-asia-northeast3}"

python -m src.evaluation.run_sql_file "${SQL_FILE}" \
  --project-id "${PROJECT_ID}" \
  --raw-dataset-id "${RAW_DATASET_ID}" \
  --review-dataset-id "${REVIEW_DATASET_ID}" \
  --location "${LOCATION}"
