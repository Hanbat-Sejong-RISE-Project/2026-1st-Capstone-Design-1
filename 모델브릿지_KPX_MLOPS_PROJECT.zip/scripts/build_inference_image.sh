#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:?PROJECT_ID env required}"
REGION="${REGION:-asia-northeast3}"
REPO="${REPO:-kpx-mlops}"
IMAGE_NAME="${IMAGE_NAME:-kpx-sequence-inference-review}"
TAG="${TAG:-portfolio-$(date +%Y%m%d-%H%M%S)}"
IMAGE_URI="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/${IMAGE_NAME}:${TAG}"

gcloud config set project "${PROJECT_ID}"

gcloud services enable artifactregistry.googleapis.com cloudbuild.googleapis.com run.googleapis.com

if ! gcloud artifacts repositories describe "${REPO}" --location="${REGION}" >/dev/null 2>&1; then
  gcloud artifacts repositories create "${REPO}" \
    --repository-format=docker \
    --location="${REGION}" \
    --description="KPX MLOps Docker images"
fi

gcloud builds submit --tag "${IMAGE_URI}" .
echo "${IMAGE_URI}"
